package dev.mfx;

/** Одна анимация. tick вызывается каждые N тиков и рисует один "кадр". */
public interface Fx {
    void tick(Ctx c);
}

package dev.mfx;

/** Математические помощники. */
public final class M {
    private M() {}

    public static double frac(double x) { return x - Math.floor(x); }

    public static double clamp(double v, double lo, double hi) { return v < lo ? lo : Math.min(v, hi); }

    public static double bez(double a, double b, double c, double d, double u) {
        double v = 1 - u;
        return v * v * v * a + 3 * v * v * u * b + 3 * v * u * u * c + u * u * u * d;
    }

    public static int lerp(int a, int b, double t) {
        t = clamp(t, 0, 1);
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int r = (int) (ar + (br - ar) * t);
        int g = (int) (ag + (bg - ag) * t);
        int bl = (int) (ab + (bb - ab) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    public static double dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

    public static double[] sub(double[] a, double[] b) { return new double[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }

    public static double[] norm(double[] a) {
        double l = Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
        if (l < 1e-9) return new double[]{0, 1, 0};
        return new double[]{a[0] / l, a[1] / l, a[2] / l};
    }

    /** Равномерные точки на единичной сфере (спираль Фибоначчи). */
    public static double[][] fib(int n) {
        double[][] r = new double[n][];
        double ga = Math.PI * (3 - Math.sqrt(5));
        for (int i = 0; i < n; i++) {
            double y = 1 - 2.0 * (i + 0.5) / n;
            double rr = Math.sqrt(1 - y * y);
            double a = i * ga;
            r[i] = new double[]{rr * Math.cos(a), y, rr * Math.sin(a)};
        }
        return r;
    }

    public static int hsv(double h, double s, double v) {
        h = frac(h);
        double hh = h * 6;
        int i = (int) hh;
        double f = hh - i;
        double p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        double r, g, b;
        switch (i % 6) {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
        return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}

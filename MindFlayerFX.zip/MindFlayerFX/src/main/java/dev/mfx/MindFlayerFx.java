package dev.mfx;

import org.bukkit.Particle;

/**
 * Истязатель разума (Mind Flayer): каплевидное тело и 8 длинных дугообразных ног.
 * Силуэт - тёмно-красная "тень", по телу и ногам текут зелёно-жёлтые потоки частиц.
 * Всё считается параметрически (кривые Безье + трубки вокруг кривых).
 */
public final class MindFlayerFx implements Fx {
    static final int GREEN = 0x39FF14, YELLOW = 0xFFE81F, DARK = 0x140202, BLOOD = 0x6E0909;
    private final double[] phi = new double[8], reach = new double[8], ph = new double[8];

    public MindFlayerFx() {
        double[] base = {30, 64, 108, 150};
        double[] rc = {0.82, 1.0, 1.0, 0.8};
        for (int p = 0; p < 4; p++) {
            for (int sd = 0; sd < 2; sd++) {
                int k = p * 2 + sd;
                phi[k] = Math.toRadians((sd == 0 ? -1 : 1) * base[p]);
                reach[k] = rc[p];
                ph[k] = k * 0.8;
            }
        }
    }

    /** Точка на оси ноги k, u in [0..1] (0 - у тела, 1 - кончик на земле). */
    private double[] pt(int k, double u, double t, double L) {
        double rc = reach[k], p = ph[k];
        double lift = 0.10 * Math.max(0, Math.sin(t * 0.05 + p * 3));
        double d = M.bez(0.05, 0.25 * rc, 0.80 * rc, rc * (1.0 + 0.02 * Math.sin(t * 0.03 + p)), u);
        double h = M.bez(0.14, 0.62, 0.55 + 0.04 * Math.sin(t * 0.04 + p), -0.5 + lift, u);
        return new double[]{Math.sin(phi[k]) * d * L, h * L, Math.cos(phi[k]) * d * L};
    }

    private static double rad(double u, double L) { return L * (0.034 * (1 - u) + 0.009); }

    private static double bodyR(double q, double L) {
        return 0.115 * L * Math.pow(Math.sin(Math.PI * Math.pow(q, 0.7)), 0.8) + 0.004 * L;
    }

    @Override
    public void tick(Ctx c) {
        double L = 46 * c.s, t = c.t;
        c.yaw = t * 0.0015;
        c.oy = 0.5 * L + 0.012 * L * Math.sin(t * 0.02);

        int ns = c.n(22), nm = c.n(18);
        for (int k = 0; k < 8; k++) {
            double[] nh = {Math.cos(phi[k]), 0, -Math.sin(phi[k])};
            // тёмная "плоть" ноги
            for (int i = 0; i < ns; i++) {
                if (((i + k + c.frame) & 1) != 0) continue;
                double u = (i + 0.5) / ns;
                double[] p = pt(k, u, t, L);
                c.cloud(p[0], p[1], p[2], ((i + k) & 1) == 0 ? DARK : BLOOD, 3.6, 8, rad(u, L) * 0.55);
            }
            // три зелёно-жёлтые жилы, текущие от тела к кончику
            for (int st = 0; st < 3; st++) {
                for (int j = 0; j < nm; j++) {
                    double u = M.frac((double) j / nm + t * 0.006 + st * 0.11);
                    double[] p = pt(k, u, t, L);
                    double[] a = pt(k, Math.min(1, u + 0.01), t, L);
                    double[] b = pt(k, Math.max(0, u - 0.01), t, L);
                    double[] T = M.norm(M.sub(a, b));
                    double[] n2 = M.norm(M.cross(T, nh));
                    double al = 2 * Math.PI * st / 3 + u * 9 + t * 0.02;
                    double r = rad(u, L) * 1.2, cs = Math.cos(al), sn = Math.sin(al);
                    c.trans(p[0] + r * (cs * nh[0] + sn * n2[0]),
                            p[1] + r * (cs * nh[1] + sn * n2[1]),
                            p[2] + r * (cs * nh[2] + sn * n2[2]),
                            (st & 1) == 0 ? GREEN : YELLOW, (st & 1) == 0 ? YELLOW : GREEN, 3.6 - 1.6 * u);
                }
            }
            double[] tip = pt(k, 1, t, L);
            c.p(Particle.ELECTRIC_SPARK, tip[0], tip[1], tip[2], 1, 0.6 * c.s, 0.02);
        }

        // тело - капля, заострённая вниз
        int nr = c.n(22);
        for (int i = 0; i < nr; i++) {
            double q = (i + 0.5) / nr;
            double y = 0.30 * L - q * 0.58 * L, r = bodyR(q, L);
            for (int m = 0; m < 9; m++) {
                if (((i + m + c.frame) & 1) != 0) continue;
                double a = 2 * Math.PI * m / 9 + q * 3 + t * 0.01;
                c.dust(r * Math.cos(a), y, r * Math.sin(a), (m & 1) == 0 ? DARK : BLOOD, 3.4);
            }
            if (i % 3 == 0) c.cloud(0, y, 0, DARK, 3.6, 10, r * 0.5);
        }
        // шесть спиральных потоков по телу сверху вниз
        int nb = c.n(26);
        for (int s = 0; s < 6; s++) {
            for (int j = 0; j < nb; j++) {
                double u = M.frac((double) j / nb + t * 0.005 + s / 6.0);
                double y = 0.30 * L - u * 0.58 * L, r = bodyR(u, L) * 1.06;
                double a = 2 * Math.PI * s / 6 + u * 6 * Math.PI + t * 0.01;
                c.trans(r * Math.cos(a), y, r * Math.sin(a),
                        (s & 1) == 0 ? GREEN : YELLOW, (s & 1) == 0 ? YELLOW : GREEN, 3.3);
            }
        }
    }
}

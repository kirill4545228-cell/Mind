package dev.mfx;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.logging.Level;

public final class MfxPlugin extends JavaPlugin implements TabExecutor {

    public record Def(String id, String desc, int period, Supplier<Fx> make) {}

    static final Map<String, Def> DEFS = new LinkedHashMap<>();

    private static void reg(String id, String desc, int period, Supplier<Fx> make) {
        DEFS.put(id, new Def(id, desc, period, make));
    }

    static {
        reg("sphere", "Огромный шар из зелёных и жёлтых потоков частиц вокруг невидимой точки", 2, SphereFx::new);
        reg("mindflayer", "Истязатель разума: тело-капля и 8 ног, по ним текут частицы", 2, MindFlayerFx::new);
        reg("galaxy", "Вращающаяся спиральная галактика с ядром", 2, Effects.Galaxy::new);
        reg("rift", "Разлом в Изнанку: кровавое кольцо, воронка и молнии-щупальца", 2, Effects.Rift::new);
        reg("tornado", "Гигантский торнадо", 2, Effects.Tornado::new);
        reg("dna", "Двойная спираль ДНК с перекладинами", 2, Effects.Dna::new);
        reg("blackhole", "Чёрная дыра: аккреционный диск, джеты, фотонное кольцо", 2, Effects.Hole::new);
        reg("phoenix", "Феникс кружит в небе и машет огненными крыльями", 2, Effects.Phoenix::new);
        reg("supernova", "Цикл сверхновой: коллапс, вспышка, ударные оболочки", 2, Effects.Supernova::new);
        reg("storm", "Грозовая туча, дождь и фрактальные молнии", 2, Effects.Storm::new);
        reg("knot", "Радужный трилистник-узел, по которому текут частицы", 2, Effects.Knot::new);
        reg("swarm", "Тысячи зелёно-жёлтых полосок медленно и хаотично плывут по огромному небу", 2, Effects.Swarm::new);
        reg("eye", "Гигантский глаз в небе: моргает, ведёт взглядом, с венами", 2, Horror.Eye::new);
        reg("reaper", "Жнец с косой и красными глазами, вокруг шепчущие души", 2, Horror.Reaper::new);
        reg("bloodrain", "Кроваво-красная туча и кровавый дождь", 2, Horror.BloodRain::new);
        reg("souls", "Шесть спиралей голубых душ поднимаются в небо", 2, Horror.Souls::new);
        reg("skull", "Огромный череп с горящими глазницами", 2, Horror.Skull::new);
        reg("claw", "Пять костяных когтей рвутся из-под земли", 2, Horror.Claw::new);
        reg("tentacles", "Девять щупалец из-под земли", 2, Horror.Tentacles::new);
        reg("pentagram", "Перевёрнутая пентаграмма с огнём на вершинах", 2, Horror.Pentagram::new);
        reg("meteors", "Метеоритный дождь с ударами о землю", 2, Horror.Meteors::new);
        reg("ghosts", "Семь призраков кружат над землёй", 2, Horror.Ghosts::new);
        reg("nuke", "Ядерный гриб: вспышка, ударная волна, шапка", 2, Horror.Nuke::new);
        reg("dragon", "Огромный дракон летает по небу и дышит огнём", 2, Horror.Dragon::new);
        reg("crows", "Стая из 150 ворон-вихрь", 2, Horror.Crows::new);
        reg("bloodmoon", "Кровавая луна с каплями", 2, Horror.BloodMoon::new);
        reg("maw", "Пасть с вращающимися кольцами зубов в земле", 2, Horror.Maw::new);
        reg("web", "Гигантская паутина с пауком", 2, Horror.Web::new);
        reg("plasma", "Плазменный шар с молниями", 2, Horror.Plasma::new);
        reg("obelisk", "Парящий обелиск с рунами и осколками", 2, Horror.Obelisk::new);
        reg("summon", "Круг призыва с рунами и лучом в небо", 2, Horror.Summon::new);
        reg("inferno", "Огненный столб", 2, Horror.Inferno::new);
        reg("watchers", "Белые глаза наблюдателей мигают по кругу", 2, Horror.Watchers::new);
        reg("chains", "Цепи свисают с неба", 2, Horror.Chains::new);
        reg("banshee", "Лицо банши кричит волнами", 2, Horror.Banshee::new);
        reg("heart", "Гигантское бьющееся сердце", 2, Horror.Heart::new);
        reg("eclipse", "Затмение с пылающей короной", 2, Horror.Eclipse::new);
        reg("aurora", "Северное сияние: двойные колышущиеся занавесы", 3, Effects.Aurora::new);
        reg("hand", "Гигантская костяная рука вырывается из-под земли и сжимает кулак", 2, Horror2.Hand::new);
        reg("skycrack", "Трещина в небе раскрывается, внутри — огненный зрачок", 2, Horror2.SkyCrack::new);
        reg("graveyard", "Кладбище: надгробия, туман, из земли тянутся руки", 2, Horror2.Graveyard::new);
        reg("gallows", "Виселица с качающимися повешенными, у одного светятся глаза", 2, Horror2.Gallows::new);
        reg("centipede", "Гигантская стоножка ползёт кругом на сотне лап", 2, Horror2.Centipede::new);
        reg("cult", "Культ: 12 фигур в капюшонах вокруг костра, кульминация — луч в небо", 2, Horror2.Cult::new);
        reg("hellgate", "Врата ада: лавовая бездна, огненные столбы, рога поднимаются из пасти", 2, Horror2.Hellgate::new);
        reg("demon", "Огромное лицо демона с рогами, горящими глазами и разевающейся пастью", 2, Horror2.Demon::new);
        reg("slender", "Тонкий безликий силуэт с щупальцами: телепортируется ближе с помехами", 2, Horror2.Slender::new);
        reg("creepfog", "Тёмный туман, в котором открываются и закрываются глаза", 2, Horror2.CreepFog::new);
        reg("seraph", "Падший серафим: шесть горящих чернеющих крыльев, кровавые слёзы", 2, Horror2.Seraph::new);
        reg("serpent", "Гигантский змей кольцами плывёт по небу, шипит языком", 2, Horror2.Serpent::new);
        reg("doomclock", "Часы Судного дня: стрелки крутятся, в полночь кровавая ударная волна", 2, Horror2.DoomClock::new);
        reg("blacksun", "Чёрное солнце с огненными трещинами, обломками и пеплопадом", 2, Horror2.BlackSun::new);
        reg("brain", "Гигантский пульсирующий мозг с нейронными молниями и пси-волнами", 2, Horror2.Brain::new);
        reg("deadtree", "Мёртвое дерево с лицом, глаза горят, вокруг кружат вороны", 2, Horror2.DeadTree::new);
        reg("ribcage", "Гигантская грудная клетка с синим пламенем души внутри", 2, Horror2.Ribcage::new);
        reg("swordrain", "Дождь из мечей: падают с неба и втыкаются в землю", 2, Horror2.SwordRain::new);
        reg("plague", "Чума: куча черепов, зелёные миазмы, рой мух и лопающиеся пузыри", 2, Horror2.Plague::new);
        reg("hypno", "Гипнотическая спираль в небе и обратная спираль на земле", 2, Horror2.Hypno::new);
        reg("cage", "Костяная клетка опускается с неба и смыкается куполом", 2, Horror2.Cage::new);
        reg("howl", "Кровавая луна и силуэт воющего волка, волны воя", 2, Horror2.Howl::new);
        reg("horseman", "Всадник без головы с пылающим мечом скачет по небу", 2, Horror2.Horseman::new);
        reg("bloodriver", "Кровавая река с всплывающими кричащими лицами", 2, Horror2.BloodRiver::new);
        reg("wendigo", "Вендиго: рогатый скелет с ледяными глазами кружит и следит", 2, Horror2.Wendigo::new);
        reg("bloodswarm", "Тысячи тёмно-красных и пепельно-серых полосок медленно плывут по небу (как на скрине)", 2, () -> new Horror2.Streaks(new int[]{0x5A0A14, 0x3A0510, 0x7A1020, 0x8A7A70, 0x6A5A50}, 0x050202, 777L));
        reg("ashswarm", "Тысячи серых и белёсых полосок пепла плывут по небу", 2, () -> new Horror2.Streaks(new int[]{0x9A9A9A, 0x6E6E6E, 0xCFCFCF, 0x4A4A4A}, 0x101010, 888L));
        reg("voidswarm", "Тысячи чёрно-фиолетовых полосок Бездны плывут по небу", 2, () -> new Horror2.Streaks(new int[]{0x2A0A3A, 0x4A1A6A, 0x120018, 0x7A3AA0}, 0x000000, 999L));
        reg("greenorb", "Тысячи мелких зелёных полосок плавно текут в одну сторону по кругам и образуют шар (бесконечный цикл)", 2, Horror2.GreenOrb::new);
    }

    private final Map<Integer, Run> runs = new LinkedHashMap<>();
    private int nextId = 1;
    private Menu menu;

    private final class Run implements Runnable {
        final int id;
        final Def def;
        final World w;
        final double x, y, z, s;
        final Fx fx;
        final int max;
        int t = 0;
        BukkitTask task;

        Run(int id, Def def, World w, double x, double y, double z, double s, int max) {
            this.id = id; this.def = def; this.w = w; this.x = x; this.y = y; this.z = z;
            this.s = s; this.max = max; this.fx = def.make().get();
        }

        @Override
        public void run() {
            if (t >= max || Bukkit.getWorld(w.getUID()) == null) {
                stop(id);
                return;
            }
            try {
                double density = getConfig().getDouble("density", 1.0);
                fx.tick(new Ctx(w, x, y, z, s, density, t, t / def.period()));
            } catch (Throwable e) {
                getLogger().log(Level.SEVERE, "Ошибка в эффекте " + def.id(), e);
                stop(id);
                return;
            }
            t += def.period();
        }
    }

    @Override
    public void onEnable() {
        saveDefaultConfig();
        menu = new Menu(this);
        getServer().getPluginManager().registerEvents(menu, this);
        if (getCommand("mfx") != null) getCommand("mfx").setExecutor(this);
        getLogger().info("MindFlayerFX включён. Эффектов: " + DEFS.size());
    }

    /** Запуск анимации в точке игрока (используется командой и меню). */
    void launch(Player p, Def d, double sc, int sec) {
        sc = M.clamp(sc, 0.2, getConfig().getDouble("max-scale", 4.0));
        if (runs.size() >= getConfig().getInt("max-active", 5)) {
            p.sendMessage("§cСлишком много активных анимаций. /mfx stop all");
            return;
        }
        Location l = p.getLocation();
        int id = nextId++;
        Run r = new Run(id, d, l.getWorld(), l.getX(), l.getY(), l.getZ(), sc,
                sec <= 0 ? Integer.MAX_VALUE : sec * 20);
        r.task = Bukkit.getScheduler().runTaskTimer(this, r, 1L, d.period());
        runs.put(id, r);
        p.sendMessage("§aЗапущено §e" + d.id() + " §7(#" + id + ", масштаб " + sc + ")");
    }

    void stopAllPublic() { stopAll(); }

    @Override
    public void onDisable() {
        stopAll();
    }

    private void stop(int id) {
        Run r = runs.remove(id);
        if (r != null && r.task != null) r.task.cancel();
    }

    private void stopAll() {
        for (Integer id : new ArrayList<>(runs.keySet())) stop(id);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("menu")) {
            if (sender instanceof Player p) {
                menu.open(p, 0);
            } else {
                sender.sendMessage("Меню доступно только игроку. /mfx help");
            }
            return true;
        }
        if (args[0].equalsIgnoreCase("help")) {
            sender.sendMessage("§e/mfx §7- меню выбора эффекта");
            sender.sendMessage("§e/mfx list §7- список анимаций");
            sender.sendMessage("§e/mfx play <имя> [масштаб] [секунд] §7- запуск в вашей точке (0 секунд = бесконечно)");
            sender.sendMessage("§e/mfx active §7- запущенные");
            sender.sendMessage("§e/mfx stop <id|all> §7- остановить");
            return true;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("list")) {
            for (Def d : DEFS.values()) sender.sendMessage("§a" + d.id() + " §7- " + d.desc());
            return true;
        }
        if (sub.equals("active")) {
            if (runs.isEmpty()) sender.sendMessage("§7Ничего не запущено.");
            for (Run r : runs.values()) {
                sender.sendMessage("§e#" + r.id + " §a" + r.def.id() + " §7масштаб " + r.s + " @ "
                        + (int) r.x + " " + (int) r.y + " " + (int) r.z);
            }
            return true;
        }
        if (sub.equals("stop")) {
            if (args.length < 2 || args[1].equalsIgnoreCase("all")) {
                stopAll();
                sender.sendMessage("§aВсе анимации остановлены.");
                return true;
            }
            try {
                stop(Integer.parseInt(args[1]));
                sender.sendMessage("§aОстановлено.");
            } catch (NumberFormatException e) {
                sender.sendMessage("§cУкажите номер или all.");
            }
            return true;
        }
        if (sub.equals("play")) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Только игрок может запускать анимации.");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage("§c/mfx play <имя> [масштаб] [секунд]");
                return true;
            }
            Def d = DEFS.get(args[1].toLowerCase());
            if (d == null) {
                sender.sendMessage("§cНет такой анимации. /mfx list");
                return true;
            }
            double sc = 1;
            int sec = 600;
            try {
                if (args.length > 2) sc = Double.parseDouble(args[2]);
                if (args.length > 3) sec = Integer.parseInt(args[3]);
            } catch (NumberFormatException e) {
                sender.sendMessage("§cМасштаб и секунды должны быть числами.");
                return true;
            }
            launch(p, d, sc, sec);
            return true;
        }
        sender.sendMessage("§c/mfx help");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("menu", "list", "play", "active", "stop", "help")) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("play")) {
            for (String s : DEFS.keySet()) if (s.startsWith(args[1].toLowerCase())) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("stop")) {
            out.add("all");
            for (Integer i : runs.keySet()) out.add(String.valueOf(i));
        } else if (args.length == 3 && args[0].equalsIgnoreCase("play")) {
            out.addAll(List.of("1", "1.5", "2"));
        } else if (args.length == 4 && args[0].equalsIgnoreCase("play")) {
            out.addAll(List.of("0", "300", "600"));
        }
        return out;
    }
}

package dev.mfx;

import org.bukkit.Particle;

import java.util.List;
import java.util.Random;

/** 25 хоррорных и эпичных долгих анимаций. */
public final class Horror {
    private Horror() {}

    // ------------------------------------------------------------ помощники
    static void ln(Ctx c, double x1, double y1, double z1, double x2, double y2, double z2, double step, int col, double size) {
        double dx = x2 - x1, dy = y2 - y1, dz = z2 - z1;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int n = Math.max(1, (int) (len / step));
        for (int i = 0; i <= n; i++) {
            double f = (double) i / n;
            c.dust(x1 + dx * f, y1 + dy * f, z1 + dz * f, col, size);
        }
    }

    /** Горизонтальное кольцо. */
    static void ring(Ctx c, double cx, double cy, double cz, double r, int n, double rot, int col, double size) {
        for (int i = 0; i < n; i++) {
            double a = rot + 2 * Math.PI * i / n;
            c.dust(cx + r * Math.cos(a), cy, cz + r * Math.sin(a), col, size);
        }
    }

    /** Вертикальное кольцо в плоскости XY. */
    static void vring(Ctx c, double cx, double cy, double cz, double r, int n, double rot, int col, double size) {
        for (int i = 0; i < n; i++) {
            double a = rot + 2 * Math.PI * i / n;
            c.dust(cx + r * Math.cos(a), cy + r * Math.sin(a), cz, col, size);
        }
    }

    static double hash(double x) {
        double s = Math.sin(x * 127.1) * 43758.5453;
        return s - Math.floor(s);
    }

    // ------------------------------------------------------------ 1. ГЛАЗ В НЕБЕ
    static boolean inLid(double x, double y, double W, double H, double open) {
        double q = 1 - (x / W) * (x / W);
        if (q <= 0) return false;
        return y <= H * q * open && y >= -0.8 * H * q * open;
    }

    public static final class Eye implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, W = 30 * s, H = 13 * s;
            c.oy = 42 * s;
            c.yaw = 0.5 * Math.sin(c.t * 0.002);
            int p = c.t % 300;
            double open = p < 270 ? 1 : Math.abs(Math.cos((p - 270) / 30.0 * Math.PI));
            open = Math.max(0.04, open);
            int n = c.n(70);
            for (int i = 0; i <= n; i++) {
                double x = -W + 2 * W * i / n, q = 1 - (x / W) * (x / W);
                c.dust(x, H * q * open, 0, 0x7A0A0A, 3.4);
                c.dust(x, -0.8 * H * q * open, 0, 0x7A0A0A, 3.4);
            }
            double st = 2.2 * s, ix = 7 * s * Math.sin(c.t * 0.01), iy = 2 * s * Math.sin(c.t * 0.013), ir = 7 * s;
            int gi = 0;
            for (double gx = -W + st; gx < W; gx += st) {
                for (double gy = -H; gy <= H; gy += st) {
                    gi++;
                    if (((gi + c.frame) & 1) != 0) continue;
                    if (!inLid(gx, gy, W, H, open) || Math.hypot(gx - ix, gy - iy) < ir) continue;
                    c.dust(gx, gy, -0.2 * s, 0xEDE6E0, 2.6);
                }
            }
            for (double rr = s; rr <= ir; rr += 1.2 * s) {
                int m = Math.max(8, (int) (rr / s * 5));
                for (int k = 0; k < m; k++) {
                    double a = 2 * Math.PI * k / m, x = ix + rr * Math.cos(a), y = iy + rr * Math.sin(a);
                    if (!inLid(x, y, W, H, open)) continue;
                    c.dust(x, y, 0, M.lerp(0xFFB000, 0xA01000, rr / ir), 2.8);
                }
            }
            for (double y = -5 * s; y <= 5 * s; y += 0.9 * s) {
                if (!inLid(ix, iy + y, W, H, open)) continue;
                double hw = 1.2 * s * Math.sqrt(Math.max(0, 1 - (y / (5 * s)) * (y / (5 * s))));
                c.dust(ix, iy + y, 0.2 * s, 0x000000, 3.8);
                if (hw > 0.6 * s) {
                    c.dust(ix + hw, iy + y, 0.2 * s, 0x000000, 3.6);
                    c.dust(ix - hw, iy + y, 0.2 * s, 0x000000, 3.6);
                }
            }
            for (int v = 0; v < 12; v++) {
                double a = 2 * Math.PI * v / 12 + 0.1, x = ix + ir * Math.cos(a), y = iy + ir * Math.sin(a);
                for (int k = 0; k < 6; k++) {
                    x += Math.cos(a) * 2.2 * s + 0.5 * s * Math.sin(c.t * 0.05 + v * 2 + k);
                    y += Math.sin(a) * 2.2 * s + 0.5 * s * Math.cos(c.t * 0.04 + v + k);
                    if (inLid(x, y, W, H, open)) c.dust(x, y, 0, 0xC01010, 1.6);
                }
            }
        }
    }

    // ------------------------------------------------------------ 2. ЖНЕЦ
    public static final class Reaper implements Fx {
        final double[][] fb = M.fib(70);

        @Override
        public void tick(Ctx c) {
            double s = 1.8 * c.s;
            c.yaw = c.t * 0.004;
            c.oy = s * (1 + 2 * Math.sin(c.t * 0.03));
            int lv = c.n(24);
            for (int l = 0; l < lv; l++) {
                double f = (double) l / lv, h = f * 22 * s, r = (6.5 * (1 - f) + 1.6 * f) * s;
                for (int m = 0; m < 12; m++) {
                    if (((l + m + c.frame) & 1) != 0) continue;
                    double a = 2 * Math.PI * m / 12 + l * 0.2 + c.t * 0.003;
                    double rr = f < 0.15 ? r * (1 + 0.18 * Math.sin(8 * a + c.t * 0.1)) : r;
                    c.dust(rr * Math.cos(a), h, rr * Math.sin(a), ((l + m) % 3 == 0) ? 0x2A1040 : 0x050505, 3.4);
                }
            }
            for (double[] p : fb) c.dust(p[0] * 3.2 * s, 24 * s + p[1] * 3.2 * s, p[2] * 3.2 * s, 0x080808, 3.2);
            c.dust(1.1 * s, 24.3 * s, 2.9 * s, 0xFF0000, 3.8);
            c.dust(-1.1 * s, 24.3 * s, 2.9 * s, 0xFF0000, 3.8);
            ln(c, 7 * s, 0, 2 * s, 7 * s, 34 * s, 2 * s, 1.2, 0x4A3A28, 2.2);
            for (int i = 0; i <= 22; i++) {
                double u = i / 22.0, bx = 7 * s - 13 * s * u, by = 34 * s + 3.5 * s * Math.sin(u * Math.PI) - 7 * s * u * u;
                c.dust(bx, by, 2 * s, 0xD8E0E8, 2.6);
                c.dust(bx, by - 0.9 * s * (1 - u * 0.8), 2 * s, 0x9AA4AC, 2.0);
            }
            c.p(Particle.END_ROD, 1 * s, 36 * s, 2 * s, 1, 0.4 * s, 0);
            ln(c, 2.5 * s, 16 * s, 0, 6.5 * s, 14 * s, 2 * s, 1.0, 0x1A1A1A, 2.4);
            c.p(Particle.SOUL, 0, 8 * s, 0, 2, 6 * s, 0.02);
        }
    }

    // ------------------------------------------------------------ 3. КРОВАВЫЙ ДОЖДЬ
    public static final class BloodRain implements Fx {
        static final int N = 420, RN = 200;
        final double[] cx = new double[N], cz = new double[N], cy = new double[N], sh = new double[N];
        final double[] rx = new double[RN], rz = new double[RN], ro = new double[RN];

        public BloodRain() {
            Random r = new Random(66);
            for (int i = 0; i < N; i++) {
                double rr = Math.sqrt(r.nextDouble()), a = r.nextDouble() * 2 * Math.PI;
                cx[i] = rr * Math.cos(a);
                cz[i] = rr * Math.sin(a);
                cy[i] = r.nextGaussian() * 0.05;
                sh[i] = r.nextDouble();
            }
            for (int i = 0; i < RN; i++) {
                double rr = Math.sqrt(r.nextDouble()) * 0.95, a = r.nextDouble() * 2 * Math.PI;
                rx[i] = rr * Math.cos(a);
                rz[i] = rr * Math.sin(a);
                ro[i] = r.nextDouble();
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s, Hc = 45 * s, Rc = 40 * s;
            c.yaw = c.t * 0.002;
            for (int i = 0; i < N; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                c.dust(cx[i] * Rc, Hc + cy[i] * Rc, cz[i] * Rc, M.lerp(0x1A0000, 0x6A0A0A, sh[i]), 3.8);
            }
            for (int i = 0; i < c.n(RN); i++) {
                double f = M.frac(ro[i] + c.t * 0.03);
                double y = Hc - f * Hc;
                c.dust(rx[i] * Rc, y, rz[i] * Rc, 0xB00000, 1.5);
                c.dust(rx[i] * Rc, y + s, rz[i] * Rc, 0x700000, 1.2);
                if (f > 0.96) c.cloud(rx[i] * Rc, 0.3, rz[i] * Rc, 0x8A0000, 2.0, 5, 0.8 * s);
            }
        }
    }

    // ------------------------------------------------------------ 4. ДУШИ
    public static final class Souls implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, H = 55 * s;
            int n = c.n(30);
            for (int h = 0; h < 6; h++) {
                for (int j = 0; j < n; j++) {
                    double u = M.frac((double) j / n + c.t * 0.004 + h / 6.0);
                    double a = h * Math.PI / 3 + u * 10 + c.t * 0.01, r = (3 + 11 * u) * s;
                    c.trans(r * Math.cos(a), u * H, r * Math.sin(a), 0x9FE8FF, 0x203060, 3.4 - 1.4 * u);
                }
            }
            c.p(Particle.SOUL, 0, 2 * s, 0, 3, 5 * s, 0.03);
            c.p(Particle.SOUL, 0, H * 0.8, 0, 3, 12 * s, 0.01);
        }
    }

    // ------------------------------------------------------------ 5. ЧЕРЕП
    static boolean skullIn(double x, double y) {
        if (y >= -2) return (x / 14) * (x / 14) + ((y - 4) / 17) * ((y - 4) / 17) < 1;
        if (y < -13) return false;
        return Math.abs(x) < 10 - (-2 - y) * 0.25;
    }

    public static final class Skull implements Fx {
        @Override
        public void tick(Ctx c) {
            double k = 1.6 * c.s;
            c.oy = 38 * c.s;
            c.yaw = 0.35 * Math.sin(c.t * 0.003);
            int gi = 0;
            for (double x = -14; x <= 14; x += 1.5) {
                for (double y = -13; y <= 21; y += 1.5) {
                    if (!skullIn(x, y)) continue;
                    double ex = (Math.abs(x) - 6) / 4.2, ey = (y - 3) / 5;
                    if (ex * ex + ey * ey < 1) continue;
                    if (y < -0.5 && y > -5 && Math.abs(x) < (-0.5 - y) * 0.45 + 0.3) continue;
                    if (y < -8 && y > -12.5 && ((Math.abs(x) + 1.1) % 2.2) < 0.35) continue;
                    gi++;
                    if (((gi + c.frame) & 1) != 0) continue;
                    c.dust(x * k, y * k, 0, (((int) (x * 0.7) + (int) (y * 0.7)) & 1) == 0 ? 0xE8E0C8 : 0xB8B098, 3.0);
                }
            }
            double fl = 0.7 + 0.3 * Math.sin(c.t * 0.3);
            for (int sg = -1; sg <= 1; sg += 2) {
                c.dust(sg * 6 * k, 3 * k, 0.2 * k, 0xFF1000, 3.6 * fl + 0.4);
                c.cloud(sg * 6 * k, 3 * k, 0.5 * k, 0xFF3000, 2.5, 4, 0.8 * k);
                c.p(Particle.FLAME, sg * 6 * k, 3 * k, 0.3 * k, 1, 0.5 * k, 0.01);
            }
            c.p(Particle.SOUL, 0, -14 * k, 0, 1, 3 * k, 0.02);
        }
    }

    // ------------------------------------------------------------ 6. КОГТИ ИЗ-ПОД ЗЕМЛИ
    public static final class Claw implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            double curl = 0.5 + 0.5 * Math.sin(c.t * 0.02);
            int ns = c.n(18);
            for (int f = 0; f < 5; f++) {
                double a = 2 * Math.PI * f / 5 + c.t * 0.002;
                double len = f == 0 ? 0.75 : 1.0;
                for (int i = 0; i < ns; i++) {
                    double u = (i + 0.5) / ns;
                    double r = M.bez(7, 10, 10 - 9 * curl, 8 - 12 * curl, u) * s;
                    double h = M.bez(0, 14, 22 - 7 * curl, 28 - 14 * curl, u) * s * len;
                    double rad = (1.3 * (1 - 0.6 * u) + 0.3) * s;
                    for (int m = 0; m < 4; m++) {
                        if (((i + m + f + c.frame) & 1) != 0) continue;
                        double b = 2 * Math.PI * m / 4 + u * 5;
                        c.dust((r + rad * Math.cos(b)) * Math.cos(a), h + rad * Math.sin(b), (r + rad * Math.cos(b)) * Math.sin(a),
                                u > 0.85 ? 0xE0E0D0 : 0x3A3030, 3.0);
                    }
                }
            }
            ring(c, 0, 0.3, 0, 8 * s, c.n(40), c.t * 0.01, 0x200000, 2.8);
            c.p(Particle.LARGE_SMOKE, 0, 0.5, 0, 3, 5 * s, 0.02);
        }
    }

    // ------------------------------------------------------------ 7. ЩУПАЛЬЦА
    public static final class Tentacles implements Fx {
        static final int T = 9;
        final double[] bx = new double[T], bz = new double[T], ph = new double[T], ln = new double[T];

        public Tentacles() {
            Random r = new Random(31);
            for (int i = 0; i < T; i++) {
                double a = r.nextDouble() * 2 * Math.PI, d = 8 + r.nextDouble() * 24;
                bx[i] = Math.cos(a) * d;
                bz[i] = Math.sin(a) * d;
                ph[i] = r.nextDouble() * 6.28;
                ln[i] = 32 + r.nextDouble() * 20;
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            int ns = c.n(26);
            for (int i = 0; i < T; i++) {
                for (int j = 0; j < ns; j++) {
                    double u = (j + 0.5) / ns;
                    double x = s * (bx[i] + 6 * Math.pow(u, 1.3) * Math.sin(c.t * 0.02 + ph[i] + u * 3.2) + 4 * u * Math.sin(c.t * 0.013 + ph[i] * 2));
                    double z = s * (bz[i] + 6 * Math.pow(u, 1.3) * Math.cos(c.t * 0.017 + ph[i] + u * 2.7));
                    double y = u * ln[i] * s, rad = s * (2.6 * (1 - u) + 0.4);
                    if (((j + i + c.frame) & 1) == 0) c.cloud(x, y, z, (j & 1) == 0 ? 0x1E0B2E : 0x3B1450, 3.6, 7, rad * 0.6);
                    if (j % 3 == 0) c.dust(x + rad, y, z, 0x9CFF4A, 1.7);
                }
                if (c.frame % 3 == 0) {
                    double u = 1;
                    double x = s * (bx[i] + 6 * Math.sin(c.t * 0.02 + ph[i] + 3.2) + 4 * Math.sin(c.t * 0.013 + ph[i] * 2));
                    double z = s * (bz[i] + 6 * Math.cos(c.t * 0.017 + ph[i] + 2.7));
                    c.p(Particle.END_ROD, x, u * ln[i] * s, z, 1, 0.3, 0);
                }
            }
        }
    }

    // ------------------------------------------------------------ 8. ПЕНТАГРАММА
    public static final class Pentagram implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 30 * s, rot = c.t * 0.004;
            int gi = 0;
            double[][] v = new double[5][2];
            for (int i = 0; i < 5; i++) {
                double a = rot + Math.PI / 2 + i * 2 * Math.PI / 5;
                v[i][0] = R * Math.cos(a);
                v[i][1] = R * Math.sin(a);
            }
            for (int i = 0; i < 5; i++) {
                double[] p = v[i], q = v[(i + 2) % 5];
                double dx = q[0] - p[0], dz = q[1] - p[1];
                int n = Math.max(1, (int) (Math.hypot(dx, dz) / 0.9));
                for (int k = 0; k <= n; k++) {
                    gi++;
                    if (((gi + c.frame) & 1) != 0) continue;
                    c.dust(p[0] + dx * k / n, 0.3, p[1] + dz * k / n, 0xFF1010, 2.8);
                }
            }
            ring(c, 0, 0.3, 0, R, c.n(150), rot, 0xC00808, 3.0);
            ring(c, 0, 0.3, 0, R * 1.12, c.n(160), -rot, 0x700404, 2.6);
            for (int i = 0; i < 5; i++) {
                double fl = 0.7 + 0.5 * Math.sin(c.t * 0.2 + i);
                for (int k = 0; k < 8; k++) {
                    double h = k * 1.8 * s * fl;
                    c.dust(v[i][0] + 0.4 * Math.sin(c.t * 0.3 + k), h, v[i][1], M.lerp(0xFFE060, 0xFF2000, k / 8.0), 2.6);
                }
                c.p(Particle.FLAME, v[i][0], 1, v[i][1], 5, 0.6 * s, 0.05);
            }
            c.p(Particle.SOUL_FIRE_FLAME, 0, 0.5, 0, 3, 6 * s, 0.02);
        }
    }

    // ------------------------------------------------------------ 9. МЕТЕОРИТЫ
    public static final class Meteors implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            int per = 240;
            for (int j = 0; j < 6; j++) {
                int tt = c.t + j * 40, b = tt / per;
                double f = (tt % per) / (double) per;
                Random r = new Random(b * 977L + j * 131L);
                double ex = (r.nextDouble() - 0.5) * 120 * s, ez = (r.nextDouble() - 0.5) * 120 * s;
                double sx = ex + (r.nextDouble() - 0.5) * 80 * s + 50 * s, sz = ez + (r.nextDouble() - 0.5) * 80 * s;
                if (f < 0.8) {
                    double g = f / 0.8;
                    for (int k = 0; k < 14; k++) {
                        double gg = g - k * 0.012;
                        if (gg < 0) break;
                        c.dust(sx + (ex - sx) * gg, 100 * s * (1 - gg), sz + (ez - sz) * gg,
                                M.lerp(0xFFF0A0, 0x802000, k / 14.0), 4 - 2.5 * k / 14.0);
                    }
                    double hx = sx + (ex - sx) * g, hy = 100 * s * (1 - g), hz = sz + (ez - sz) * g;
                    c.cloud(hx, hy, hz, 0xFF8000, 4, 10, 1.2 * s);
                    c.p(Particle.FLAME, hx, hy, hz, 3, 0.5 * s, 0.02);
                } else {
                    double q = (f - 0.8) / 0.2;
                    ring(c, ex, 0.5, ez, q * 18 * s + 0.5, 36, 0, 0xFF6000, 3.0);
                    c.p(Particle.LARGE_SMOKE, ex, 0.5, ez, 4, 3 * s, 0.02);
                    if (q < 0.3) c.p(Particle.END_ROD, ex, 1, ez, 20, 3 * s, 0.3);
                    c.cloud(ex, 0.5, ez, 0xFF5000, 4, 8, 2 * s * (1 + q * 3));
                }
            }
        }
    }

    // ------------------------------------------------------------ 10. ПРИЗРАКИ
    public static final class Ghosts implements Fx {
        final double[][] fb = M.fib(40);

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            for (int g = 0; g < 7; g++) {
                double ang = c.t * 0.008 + g * 2 * Math.PI / 7, R = (24 + 6 * Math.sin(c.t * 0.01 + g)) * s;
                c.ox = R * Math.cos(ang);
                c.oz = R * Math.sin(ang);
                c.oy = (10 + 4 * Math.sin(c.t * 0.03 + g * 1.3)) * s;
                c.yaw = -ang;
                for (double[] p : fb) c.dust(p[0] * 2.2 * s, 7 * s + p[1] * 2.2 * s, p[2] * 2.2 * s, 0xDDEEFF, 2.2);
                for (int l = 0; l < 9; l++) {
                    double f = l / 9.0, y = (7 * s) * (1 - f), r = 2.2 * s * (1 + f * 0.6);
                    for (int m = 0; m < 8; m++) {
                        if (((l + m + c.frame) & 1) != 0) continue;
                        double a = 2 * Math.PI * m / 8;
                        double rr = r * (1 + 0.25 * Math.sin(6 * a + c.t * 0.15 + l) * f);
                        c.dust(rr * Math.cos(a), y, rr * Math.sin(a), M.lerp(0xDDEEFF, 0x6080A0, f), 2.4);
                    }
                }
                c.dust(0.8 * s, 7.4 * s, 2.0 * s, 0x000000, 3.4);
                c.dust(-0.8 * s, 7.4 * s, 2.0 * s, 0x000000, 3.4);
                c.dust(0, 6.2 * s, 2.1 * s, 0x000000, 3.0);
                c.dust(0, 5.7 * s, 2.1 * s, 0x000000, 3.0);
                c.p(Particle.SOUL, 0, 3 * s, -1 * s, 1, 0.3 * s, 0);
            }
        }
    }

    // ------------------------------------------------------------ 11. ЯДЕРНЫЙ ГРИБ
    public static final class Nuke implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            int p = c.t % 700;
            double age = p / 700.0;
            if (p < 12) {
                c.cloud(0, 3 * s, 0, 0xFFFFFF, 4, 70, 4 * s);
                c.p(Particle.END_ROD, 0, 3 * s, 0, 80, 5 * s, 0.5);
            }
            double sw = p * 0.35 * s;
            if (sw < 90 * s) ring(c, 0, 0.5, 0, sw + 1, c.n(120), 0, 0xFFD0A0, 3.0);
            if (p < 150) {
                double r = p * 0.15 * s;
                for (double[] q : M.fib(c.n(160))) c.dust(q[0] * r, r * 0.8 + q[1] * r, q[2] * r, M.lerp(0xFFF0A0, 0xFF4000, p / 150.0), 3.6);
            }
            double H = Math.min(p * 0.22, 48) * s;
            int lv = c.n(20);
            for (int l = 0; l < lv; l++) {
                double f = (double) l / lv, y = f * H, r = 3.5 * s * (1 + 0.15 * Math.sin(l * 1.3 - c.t * 0.1));
                for (int m = 0; m < 6; m++) {
                    double a = 2 * Math.PI * m / 6 + l * 0.5 + c.t * 0.05;
                    c.dust(r * Math.cos(a), y, r * Math.sin(a), M.lerp(0xFF9020, 0x5A5A5A, Math.max(age, 1 - f) * 0.9), 3.4);
                }
            }
            if (p > 30 && age < 0.85) {
                double R = Math.min(20 * s, (p - 30) * 0.12 * s), tube = Math.min(7 * s, (p - 30) * 0.05 * s);
                int nu = c.n(30), nv = 12;
                for (int u = 0; u < nu; u++) {
                    for (int v = 0; v < nv; v++) {
                        if (((u + v + c.frame) & 1) != 0) continue;
                        double a = 2 * Math.PI * u / nu, b = 2 * Math.PI * v / nv + c.t * 0.06;
                        double rr = R + tube * Math.cos(b);
                        c.dust(rr * Math.cos(a), H + tube * Math.sin(b), rr * Math.sin(a),
                                M.lerp(0xFF8A20, 0x4A4A4A, Math.min(1, age * 1.5 + 0.5 * (1 - Math.sin(b)) * 0.5)), 3.6);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ 12. ДРАКОН
    public static final class Dragon implements Fx {
        static double[] P(double tt, double s) {
            double a = tt * 0.007;
            return new double[]{s * (42 * Math.cos(a) + 14 * Math.cos(2.3 * a)), s * (48 + 10 * Math.sin(1.7 * a)),
                    s * (42 * Math.sin(a) + 14 * Math.sin(2.3 * a))};
        }

        final double[][] fb = M.fib(40);

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            int segs = 64;
            for (int k = 0; k < segs; k++) {
                double[] p = P(c.t - k * 10.0, s);
                double rk = s * (k < 3 ? 3.6 : 3.4 - 2.9 * k / segs);
                if (((k + c.frame) & 1) == 0) c.cloud(p[0], p[1], p[2], (k & 1) == 0 ? 0x0B3D0B : 0xC9A227, 3.6, 8, rk * 0.55);
                if (k % 2 == 0 && k > 2) c.dust(p[0], p[1] + rk + 1.2 * s, p[2], 0xC9A227, 2.2);
            }
            double[] h = P(c.t, s), pb = P(c.t - 6, s);
            double[] T = M.norm(M.sub(h, pb)), up = {0, 1, 0};
            double[] side = M.norm(M.cross(T, up)), u2 = M.cross(side, T);
            double[] hc = {h[0] + T[0] * 3 * s, h[1] + T[1] * 3 * s, h[2] + T[2] * 3 * s};
            for (double[] f : fb) {
                c.dust(hc[0] + T[0] * f[0] * 4 * s + side[0] * f[1] * 2.6 * s + u2[0] * f[2] * 2.2 * s,
                        hc[1] + T[1] * f[0] * 4 * s + side[1] * f[1] * 2.6 * s + u2[1] * f[2] * 2.2 * s,
                        hc[2] + T[2] * f[0] * 4 * s + side[2] * f[1] * 2.6 * s + u2[2] * f[2] * 2.2 * s, 0x1C5A1C, 3.0);
            }
            for (int sg = -1; sg <= 1; sg += 2) {
                double[] e = new double[3], hn = new double[3];
                for (int i = 0; i < 3; i++) {
                    e[i] = hc[i] + T[i] * 2.2 * s + sg * side[i] * 1.3 * s + u2[i] * 0.8 * s;
                    hn[i] = hc[i] + u2[i] * 2 * s + sg * side[i] * 1.5 * s;
                }
                c.dust(e[0], e[1], e[2], 0xFF2000, 3.6);
                ln(c, hn[0], hn[1], hn[2], hn[0] + (-T[0] * 0.6 + u2[0] * 0.7) * 6 * s, hn[1] + (-T[1] * 0.6 + u2[1] * 0.7) * 6 * s,
                        hn[2] + (-T[2] * 0.6 + u2[2] * 0.7) * 6 * s, 1.2, 0xE8E0C0, 2.4);
            }
            for (int i = 0; i < 10; i++) {
                double d = (4 + i * 2.2) * s, spr = (0.4 + 0.35 * i) * s;
                c.p(Particle.FLAME, hc[0] + T[0] * d, hc[1] + T[1] * d, hc[2] + T[2] * d, 4, spr, 0.03);
                if (i % 3 == 0) c.p(Particle.LARGE_SMOKE, hc[0] + T[0] * d, hc[1] + T[1] * d, hc[2] + T[2] * d, 1, spr, 0.02);
            }
            double[] sh = P(c.t - 80, s), sa = P(c.t - 86, s);
            double[] T2 = M.norm(M.sub(sh, sa)), s2 = M.norm(M.cross(T2, up));
            double flap = 0.35 + 0.6 * Math.sin(c.t * 0.1);
            double[][] prev = new double[2][];
            for (int i = 0; i < 4; i++) {
                double L = (22 - 3 * i) * s;
                for (int sg = -1; sg <= 1; sg += 2) {
                    double[] tip = new double[3];
                    for (int j = 0; j < 3; j++) {
                        double dir = sg * s2[j] * Math.cos(flap) + up[j] * Math.sin(flap) - T2[j] * 0.35 * i;
                        tip[j] = sh[j] + dir * L;
                    }
                    ln(c, sh[0], sh[1], sh[2], tip[0], tip[1], tip[2], 1.3, 0x1C1C1C, 2.4);
                    int idx = sg < 0 ? 0 : 1;
                    if (prev[idx] != null) ln(c, prev[idx][0], prev[idx][1], prev[idx][2], tip[0], tip[1], tip[2], 1.4, 0x3A0A0A, 2.2);
                    prev[idx] = tip;
                }
            }
        }
    }

    // ------------------------------------------------------------ 13. СТАЯ ВОРОН
    public static final class Crows implements Fx {
        static final int N = 150;
        final double[] ph = new double[N], u1 = new double[N], u2 = new double[N], sp = new double[N];

        public Crows() {
            Random r = new Random(13);
            for (int i = 0; i < N; i++) {
                ph[i] = r.nextDouble() * 6.28;
                u1[i] = r.nextDouble();
                u2[i] = r.nextDouble();
                sp[i] = 0.015 + r.nextDouble() * 0.012;
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            c.oy = 8 * s;
            for (int i = 0; i < N; i++) {
                double a = ph[i] + c.t * sp[i], r = (10 + 35 * u1[i]) * s * (1 + 0.3 * Math.sin(c.t * 0.01 + i));
                double y = (u2[i] * 30 + 6 * Math.sin(c.t * 0.03 + i)) * s;
                double ca = Math.cos(a), sa = Math.sin(a), fl = 0.7 * s * Math.sin(c.t * 0.6 + i);
                c.dust(r * ca, y, r * sa, 0x050505, 3.0);
                c.dust(r * ca + ca * 0.9 * s, y + fl, r * sa + sa * 0.9 * s, 0x0A0A0A, 2.4);
                c.dust(r * ca - ca * 0.9 * s, y - fl, r * sa - sa * 0.9 * s, 0x0A0A0A, 2.4);
            }
            c.p(Particle.ASH, 0, 15 * s, 0, 30, 30 * s, 0);
        }
    }

    // ------------------------------------------------------------ 14. КРОВАВАЯ ЛУНА
    public static final class BloodMoon implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 22 * s;
            c.oy = (62 + 8 * Math.sin(c.t * 0.001)) * s;
            c.yaw = 0.5;
            int gi = 0;
            double st = 1.6 * s;
            for (double rr = st; rr <= R; rr += st) {
                int m = Math.max(6, (int) (2 * Math.PI * rr / st));
                for (int k = 0; k < m; k++) {
                    gi++;
                    if (((gi + c.frame) & 1) != 0) continue;
                    double a = 2 * Math.PI * k / m, x = rr * Math.cos(a), y = rr * Math.sin(a);
                    double cr = 0.5 + 0.5 * Math.sin(x * 0.7 / s) * Math.sin(y * 0.9 / s + 1);
                    c.dust(x, y, 0, M.lerp(0x5A0808, 0xC01818, cr), 3.4);
                }
            }
            for (int i = 0; i < c.n(90); i++) {
                double a = 2 * Math.PI * i / c.n(90), rr = R * (1.1 + 0.25 * hash(i + Math.floor(c.t / 20.0)));
                c.dust(rr * Math.cos(a), rr * Math.sin(a), 0, 0xFF2020, 1.5);
            }
            for (int d = 0; d < 20; d++) {
                double x = (d - 10) * R * 0.09;
                double f = M.frac(hash(d * 3.1) + c.t * 0.01);
                double base = -Math.sqrt(Math.max(0, R * R - x * x));
                c.dust(x, base - f * 40 * s, 0, 0xA00000, 1.6);
            }
        }
    }

    // ------------------------------------------------------------ 15. ПАСТЬ
    public static final class Maw implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            double[] rad = {8, 16, 24, 32};
            int[] cnt = {16, 24, 32, 40};
            for (int k = 0; k < 4; k++) {
                double r = rad[k] * s, dir = (k & 1) == 0 ? 1 : -1, rot = dir * c.t * 0.01;
                ring(c, 0, 0.3, 0, r, c.n(cnt[k] * 3), rot, 0x5A0000, 3.0);
                double hh = (3 + 2 * Math.sin(c.t * 0.05 + k)) * s;
                for (int i = 0; i < cnt[k]; i++) {
                    double a = rot + 2 * Math.PI * i / cnt[k];
                    double bx = r * Math.cos(a), bz = r * Math.sin(a), tx = r * 0.8 * Math.cos(a), tz = r * 0.8 * Math.sin(a);
                    c.dust(bx, 0.3, bz, 0xEEE8C0, 2.8);
                    c.dust((bx + tx) / 2, hh * 0.55, (bz + tz) / 2, 0xEEE8C0, 2.6);
                    c.dust(tx, hh, tz, 0xFFFFFF, 2.4);
                }
            }
            c.cloud(0, 1, 0, 0xFF0000, 3, 12, 4 * s);
            c.p(Particle.LARGE_SMOKE, 0, 1, 0, 3, 4 * s, 0.03);
        }
    }

    // ------------------------------------------------------------ 16. ПАУТИНА С ПАУКОМ
    public static final class Web implements Fx {
        final double[][] fb = M.fib(60);

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            c.oy = 38 * s;
            c.yaw = 0.4;
            int spokes = 12, gi = 0;
            for (int i = 0; i < spokes; i++) {
                double a = 2 * Math.PI * i / spokes;
                for (double r = 2 * s; r <= 34 * s; r += 1.5 * s) {
                    gi++;
                    if (((gi + c.frame) & 1) != 0) continue;
                    c.dust(r * Math.cos(a), r * Math.sin(a), 1.5 * s * Math.sin(r * 0.1 / s + c.t * 0.03), 0xDDDDDD, 1.5);
                }
            }
            for (double th = 0; th < 2 * Math.PI * 6; th += 0.12) {
                gi++;
                if (((gi + c.frame) & 1) != 0) continue;
                double r = (3 + th * 0.8) * s;
                if (r > 34 * s) break;
                c.dust(r * Math.cos(th), r * Math.sin(th), 1.5 * s * Math.sin(r * 0.1 / s + c.t * 0.03), 0xCCCCCC, 1.4);
            }
            double px = 8 * s * Math.sin(c.t * 0.004), py = 6 * s * Math.sin(c.t * 0.0033 + 1);
            for (double[] f : fb) {
                c.dust(px + f[0] * 3.5 * s, py + f[1] * 3.5 * s - 3 * s, f[2] * 3.5 * s, 0x0A0A0A, 3.2);
                if (f[1] < -0.7 && f[2] > 0) c.dust(px + f[0] * 3.5 * s, py + f[1] * 3.5 * s - 3 * s, f[2] * 3.5 * s, 0xFF0000, 3.0);
            }
            for (int i = 0; i < 6; i++) c.dust(px + (i - 2.5) * 0.5 * s, py + 1.2 * s, 2.8 * s, 0xFF0000, 2.4);
            for (int l = 0; l < 8; l++) {
                double sg = l < 4 ? 1 : -1, a = (l % 4) * 0.5 - 0.7;
                double k1 = Math.sin(c.t * 0.08 + l);
                double jx = px + sg * 5 * s, jy = py + (3 + 2 * Math.cos(a)) * s + k1 * s, jz = (a * 3) * s;
                double ex = px + sg * 11 * s, ey = py + (-1 + 6 * Math.sin(a * 2 + c.t * 0.05)) * s, ez = (a * 6) * s;
                ln(c, px + sg * 2 * s, py, a * s, jx, jy, jz, 1.0, 0x0A0A0A, 2.6);
                ln(c, jx, jy, jz, ex, ey, ez, 1.0, 0x0A0A0A, 2.4);
            }
        }
    }

    // ------------------------------------------------------------ 17. ПЛАЗМЕННЫЙ ШАР
    public static final class Plasma implements Fx {
        final double[][] fb = M.fib(130);

        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 18 * s;
            c.oy = 30 * s;
            c.yaw = c.t * 0.01;
            for (int i = 0; i < fb.length; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                c.dust(fb[i][0] * R, fb[i][1] * R, fb[i][2] * R, 0x6020A0, 1.3);
            }
            c.yaw = 0;
            long b = c.t / 4;
            for (int k = 0; k < 10; k++) {
                Random r = new Random(b * 53L + k * 7919L);
                double[] d = M.norm(new double[]{r.nextGaussian(), r.nextGaussian(), r.nextGaussian()});
                double[] end = {d[0] * R, d[1] * R, d[2] * R};
                List<double[]> pts = Effects.Storm.bolt(r, new double[]{0, 0, 0}, end, 3 * s);
                for (int i = 0; i < pts.size() - 1; i++) {
                    Effects.Storm.line(c, pts.get(i), pts.get(i + 1), 1.0, i < 12 ? 0xFFFFFF : 0xA070FF, 2.0);
                }
                c.p(Particle.ELECTRIC_SPARK, end[0], end[1], end[2], 2, 0.4 * s, 0.05);
            }
            c.cloud(0, 0, 0, 0xE0C8FF, 4, 14, 2 * s);
        }
    }

    // ------------------------------------------------------------ 18. ОБЕЛИСК
    public static final class Obelisk implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, W = 3.5 * s, H = 48 * s;
            c.oy = (10 + 2 * Math.sin(c.t * 0.02)) * s;
            c.yaw = c.t * 0.005;
            double[][] cr = {{W, W}, {-W, W}, {-W, -W}, {W, -W}};
            for (int i = 0; i < 4; i++) {
                double[] a = cr[i], b = cr[(i + 1) % 4];
                ln(c, a[0], 0, a[1], a[0], H, a[1], 1.4, 0x20202C, 2.6);
                ln(c, a[0], H, a[1], 0, H + 8 * s, 0, 1.4, 0x20202C, 2.6);
                int gi = 0;
                for (double h = 1.5 * s; h < H; h += 2 * s) {
                    for (int k = 1; k < 6; k++) {
                        gi++;
                        if (((gi + c.frame) & 1) != 0) continue;
                        double f = k / 6.0;
                        double x = a[0] + (b[0] - a[0]) * f, z = a[1] + (b[1] - a[1]) * f;
                        boolean rune = ((int) (h / (2 * s)) + k + i) % 5 == 0;
                        double glow = 0.5 + 0.5 * Math.sin(c.t * 0.1 + h * 0.2);
                        if (rune) c.dust(x * 1.05, h, z * 1.05, M.lerp(0x20A0A0, 0x60FFFF, glow), 2.8);
                        else c.dust(x, h, z, 0x0A0A12, 2.8);
                    }
                }
            }
            for (int j = 0; j < 12; j++) {
                double a = c.t * 0.015 + j * 2 * Math.PI / 12, r = 14 * s, y = (14 + 22 * (j / 12.0) + 3 * Math.sin(c.t * 0.04 + j)) * s;
                double x = r * Math.cos(a), z = r * Math.sin(a), d = 1.2 * s;
                c.dust(x, y + d, z, 0x60FFFF, 2.8);
                c.dust(x, y - d, z, 0x60FFFF, 2.8);
                c.dust(x + d * 0.7, y, z, 0x20A0A0, 2.6);
                c.dust(x - d * 0.7, y, z, 0x20A0A0, 2.6);
            }
            if ((c.t / 20) % 3 != 2) {
                for (int k = 0; k < 14; k++) c.p(Particle.END_ROD, 0, H + 8 * s + k * 4 * s, 0, 1, 0.3, 0);
            }
            ring(c, 0, -9.5 * s, 0, 10 * s, c.n(60), c.t * 0.02, 0x20A0A0, 2.8);
        }
    }

    // ------------------------------------------------------------ 19. КРУГ ПРИЗЫВА
    public static final class Summon implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 26 * s;
            double rot = c.t * 0.006;
            ring(c, 0, 0.3, 0, R, c.n(140), rot, 0xB040FF, 3.0);
            ring(c, 0, 0.3, 0, R * 0.85, c.n(120), -rot, 0x8020D0, 2.8);
            ring(c, 0, 0.3, 0, R * 0.55, c.n(80), rot * 2, 0x6010A0, 2.6);
            for (int g = 0; g < 12; g++) {
                double a = (g % 2 == 0 ? rot : -rot) + 2 * Math.PI * g / 12, r = R * 0.92;
                double cx = r * Math.cos(a), cz = r * Math.sin(a);
                Random rn = new Random(g * 4099L);
                double px = 0, pz = 0;
                for (int i = 0; i < 5; i++) {
                    double nx = (rn.nextDouble() - 0.5) * 3.2 * s, nz = (rn.nextDouble() - 0.5) * 3.2 * s;
                    if (i > 0) ln(c, cx + px, 0.3, cz + pz, cx + nx, 0.3, cz + nz, 0.7, 0xE0A0FF, 2.2);
                    px = nx;
                    pz = nz;
                }
            }
            double H = 80 * s;
            for (int k = 0; k < c.n(40); k++) {
                double y = k * H / 40, w = 1 + 0.5 * Math.sin(c.t * 0.1 + k);
                c.dust(0.8 * s * w * Math.cos(k), y, 0.8 * s * w * Math.sin(k), 0xD090FF, 3.4);
                double a = k * 0.7 + c.t * 0.05 + y * 0.1;
                c.dust(4 * s * Math.cos(a), y, 4 * s * Math.sin(a), 0xB040FF, 2.4);
                if (k % 4 == 0) c.p(Particle.END_ROD, 0, y, 0, 1, 0.5 * s, 0);
            }
            double f = M.frac(c.t / 100.0);
            ring(c, 0, 0.5, 0, f * R * 1.3, c.n(100), 0, 0xFFFFFF, 2.6);
        }
    }

    // ------------------------------------------------------------ 20. ОГНЕННЫЙ СТОЛБ
    public static final class Inferno implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, H = 70 * s;
            int lv = c.n(40);
            for (int l = 0; l < lv; l++) {
                double f = (double) l / lv, y = f * H;
                double rr = (9 - 6 * f) * s * (0.7 + 0.3 * Math.sin(y * 0.3 / s - c.t * 0.2));
                for (int m = 0; m < 4; m++) {
                    double a = l * 2.1 + m * 1.57 + c.t * 0.15 * (1 + f);
                    double rf = 0.4 + 0.6 * hash(l * 7.0 + m + c.frame);
                    int col = M.lerp(0xFFE060, 0xFF3000, rf);
                    if (f > 0.7) col = M.lerp(col, 0x303030, (f - 0.7) / 0.3);
                    c.dust(rr * rf * Math.cos(a), y, rr * rf * Math.sin(a), col, 3.4 - f);
                }
            }
            int ne = c.n(30);
            for (int j = 0; j < ne; j++) {
                double f = M.frac((double) j / ne + c.t * 0.01), r = (10 + 8 * f) * s, a = j * 2.4 + f * 8 + c.t * 0.04;
                c.dust(r * Math.cos(a), f * H * 1.1, r * Math.sin(a), 0xFF8020, 1.5);
            }
            ring(c, 0, 0.5, 0, 14 * s, c.n(60), c.t * 0.05, 0xFF4000, 2.6);
            c.p(Particle.FLAME, 0, 1, 0, 10, 12 * s, 0.05);
            c.p(Particle.LARGE_SMOKE, 0, H, 0, 5, 6 * s, 0.02);
        }
    }

    // ------------------------------------------------------------ 21. НАБЛЮДАТЕЛИ
    public static final class Watchers implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            for (int i = 0; i < 14; i++) {
                double a = 2 * Math.PI * i / 14 + c.t * 0.0003, R = (42 + 8 * hash(i)) * s;
                double ph = hash(i * 5.0) * 400;
                if (M.frac((c.t + ph) / 400.0) > 0.7) continue;
                c.ox = R * Math.cos(a);
                c.oz = R * Math.sin(a);
                c.oy = (8 + 22 * hash(i * 9.0)) * s;
                c.yaw = Math.atan2(-Math.cos(a), -Math.sin(a));
                int gi = 0;
                for (int sg = -1; sg <= 1; sg += 2) {
                    for (int x = 0; x < 5; x++) {
                        for (int y = 0; y < 3; y++) {
                            gi++;
                            if (((gi + c.frame) & 1) != 0) continue;
                            c.dust(sg * 1.5 * s + (x - 2) * 0.6 * s, (y - 1) * 0.6 * s, 0, 0xFFFFFF, 1.9);
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ 22. ЦЕПИ С НЕБА
    public static final class Chains implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, Hb = 15 * s;
            for (int ch = 0; ch < 5; ch++) {
                double a = 2 * Math.PI * ch / 5, bx = 26 * s * Math.cos(a), bz = 26 * s * Math.sin(a), ph = ch * 1.7;
                for (int k = 0; k < 22; k++) {
                    if (((k + ch + c.frame) & 1) != 0) continue;
                    double y = Hb + k * 2.4 * s;
                    double x = bx + 3 * s * Math.sin(c.t * 0.02 + ph + y * 0.04);
                    double z = bz + 3 * s * Math.cos(c.t * 0.017 + ph + y * 0.05);
                    for (int j = 0; j < 6; j++) {
                        double t = 2 * Math.PI * j / 6, wa = 0.5 * s * Math.cos(t), hb = 0.9 * s * Math.sin(t);
                        int col = (k & 1) == 0 ? 0x6A6A6A : 0x4A3A30;
                        if ((k & 1) == 0) c.dust(x + wa, y + hb, z, col, 2.4);
                        else c.dust(x, y + hb, z + wa, col, 2.4);
                    }
                }
                double x = bx + 3 * s * Math.sin(c.t * 0.02 + ph + Hb * 0.04), z = bz + 3 * s * Math.cos(c.t * 0.017 + ph + Hb * 0.05);
                ring(c, x, Hb - 2 * s, z, 3 * s, c.n(24), 0, 0x9A2020, 2.6);
                if (c.frame % 5 == ch) c.p(Particle.ELECTRIC_SPARK, x, Hb - 3 * s, z, 3, 1.5 * s, 0.05);
            }
        }
    }

    // ------------------------------------------------------------ 23. БАНШИ
    public static final class Banshee implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            c.oy = 30 * s;
            c.yaw = 0.7;
            int gi = 0;
            double st = 1.3 * s, W = 7 * s, H = 10 * s;
            double mouth = 0.6 + 0.4 * Math.sin(c.t * 0.3);
            for (double x = -W; x <= W; x += st) {
                for (double y = -H; y <= H; y += st) {
                    if ((x / W) * (x / W) + (y / H) * (y / H) > 1) continue;
                    double ex = (Math.abs(x) - 2.6 * s) / (1.4 * s), ey = (y - 3 * s) / (2 * s);
                    boolean eye = ex * ex + ey * ey < 1;
                    double mx = x / (2.2 * s), my = (y + 5 * s) / (3 * s * mouth);
                    boolean mo = mx * mx + my * my < 1;
                    gi++;
                    if (((gi + c.frame) & 1) != 0 && !eye && !mo) continue;
                    c.dust(x + 0.15 * s * Math.sin(c.t * 1.7 + y), y, 0, (eye || mo) ? 0x000000 : 0xCFE8FF, 3.0);
                }
            }
            for (int k = 0; k < 6; k++) {
                double f = M.frac(c.t / 120.0 + k / 6.0);
                vring(c, 0, -5 * s, f * 80 * s, (5 + 22 * f) * s, c.n(48), 0, M.lerp(0xE0F0FF, 0x203050, f), 3.0 - 1.5 * f);
            }
            c.p(Particle.SOUL, 0, -3 * s, 2 * s, 1, 3 * s, 0.03);
        }
    }

    // ------------------------------------------------------------ 24. СЕРДЦЕ
    public static final class Heart implements Fx {
        @Override
        public void tick(Ctx c) {
            double k = 1.1 * c.s;
            c.oy = 40 * c.s;
            c.yaw = c.t * 0.01;
            int p = c.t % 64;
            double beat = (p >= 0 && p < 8) ? Math.sin(p / 8.0 * Math.PI) : (p >= 14 && p < 22) ? 0.6 * Math.sin((p - 14) / 8.0 * Math.PI) : 0;
            double b = 1 + 0.14 * beat;
            int nt = c.n(28), nf = 20;
            for (int i = 0; i < nt; i++) {
                double th = Math.PI * (i + 0.5) / nt;
                double x = 16 * Math.pow(Math.sin(th), 3);
                double y = 13 * Math.cos(th) - 5 * Math.cos(2 * th) - 2 * Math.cos(3 * th) - Math.cos(4 * th);
                for (int j = 0; j < nf; j++) {
                    if (((i + j + c.frame) & 1) != 0) continue;
                    double f = 2 * Math.PI * j / nf;
                    c.dust(x * Math.cos(f) * k * b, y * k * b, x * Math.sin(f) * 0.65 * k * b,
                            (i + j) % 3 == 0 ? 0xC00020 : 0x8A0010, 3.4);
                }
            }
            for (int v = 0; v < 3; v++) {
                double off = (v - 1) * 4 * k;
                for (int i = 0; i < 16; i++) {
                    double u = i / 15.0;
                    c.dust(off + 6 * k * u * (v - 1), 13 * k * b + u * 14 * k, 2 * k * Math.sin(u * 3 + v), 0xD01030, 2.8 - 0.8 * u);
                }
            }
            for (int d = 0; d < 6; d++) {
                double f = M.frac(d / 6.0 + c.t * 0.015);
                c.dust(1.5 * k * Math.sin(d * 2), -15 * k - f * 30 * k, 1.5 * k * Math.cos(d * 2), 0xA00000, 1.8);
            }
            if (beat > 0.5) c.p(Particle.LARGE_SMOKE, 0, 0, 0, 3, 8 * k, 0.05);
        }
    }

    // ------------------------------------------------------------ 25. ЗАТМЕНИЕ
    public static final class Eclipse implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 18 * s;
            c.oy = 62 * s;
            c.yaw = 0.5;
            int gi = 0;
            double st = 1.4 * s;
            for (double rr = 0; rr <= R; rr += st) {
                int m = Math.max(1, (int) (2 * Math.PI * rr / st));
                for (int k = 0; k < m; k++) {
                    gi++;
                    if (((gi + c.frame) & 1) != 0) continue;
                    double a = 2 * Math.PI * k / m;
                    c.dust(rr * Math.cos(a), rr * Math.sin(a), 0, 0x000000, 3.8);
                }
            }
            int rays = c.n(90);
            for (int i = 0; i < rays; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                double a = 2 * Math.PI * i / rays, L = (8 + 8 * Math.sin(c.t * 0.03 + i * 1.7)) * s * (0.5 + hash(i));
                for (int k = 0; k <= 6; k++) {
                    double r = R * 1.02 + k * L / 6;
                    c.dust(r * Math.cos(a), r * Math.sin(a), 0, M.lerp(0xFFFFFF, 0x805010, k / 6.0), 3.0 - 1.4 * k / 6.0);
                }
            }
            double pulse = 0.6 + 0.4 * Math.sin(c.t * 0.1);
            c.cloud(R * 0.96, R * 0.28, 0, 0xFFFFFF, 4, 10, 1.5 * s * pulse);
            c.p(Particle.END_ROD, R * 0.96, R * 0.28, 0, 1, 1.2 * s, 0);
        }
    }
}

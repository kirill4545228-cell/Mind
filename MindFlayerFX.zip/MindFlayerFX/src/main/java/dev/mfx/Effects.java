package dev.mfx;

import org.bukkit.Particle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** 10 больших долгих анимаций. */
public final class Effects {
    private Effects() {}

    static final int GREEN = 0x39FF14, YELLOW = 0xFFE81F;

    // ---------------------------------------------------------------- 1. ГАЛАКТИКА
    public static final class Galaxy implements Fx {
        static final int N = 1100;
        final double[] r = new double[N], th = new double[N], y = new double[N];

        public Galaxy() {
            Random rn = new Random(77);
            for (int i = 0; i < N; i++) {
                r[i] = 0.03 + Math.pow(rn.nextDouble(), 0.75) * 0.97;
                int arm = rn.nextInt(4);
                th[i] = arm * Math.PI / 2 + 4.2 * Math.log(1 + r[i] * 5) + rn.nextGaussian() * (0.10 + 0.12 * r[i]);
                y[i] = rn.nextGaussian() * (0.02 + 0.05 * (1 - r[i]));
            }
        }

        @Override
        public void tick(Ctx c) {
            double R = 42 * c.s;
            c.oy = 30 * c.s;
            c.yaw = c.t * 0.002;
            double tilt = 0.55, ct = Math.cos(tilt), st = Math.sin(tilt);
            for (int i = 0; i < N; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                double a = th[i] + c.t * 0.012 * Math.pow(r[i] + 0.08, -0.5);
                double x = R * r[i] * Math.cos(a), z = R * r[i] * Math.sin(a), yy = R * y[i];
                c.dust(x, yy * ct - z * st, yy * st + z * ct,
                        M.hsv(0.13 + 0.62 * r[i], 0.2 + 0.75 * r[i], 1.0), 2.4 + (1 - r[i]) * 1.5);
            }
            c.cloud(0, 0, 0, 0xFFF4C0, 4, 10, R * 0.06);
            c.p(Particle.END_ROD, 0, 0, 0, 3, R * 0.05, 0.01);
        }
    }

    // ---------------------------------------------------------------- 2. РАЗЛОМ (Изнанка)
    public static final class Rift implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, A = 17 * s, B = 9.5 * s;
            c.oy = A + 2 * s;
            c.yaw = 0.6 + 0.3 * Math.sin(c.t * 0.004);
            int n = c.n(200);
            for (int i = 0; i < n; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                double a = 2 * Math.PI * i / n;
                double w = 1 + 0.07 * Math.sin(7 * a + c.t * 0.1) + 0.04 * Math.sin(13 * a - c.t * 0.07);
                c.dust(B * w * Math.cos(a), A * w * Math.sin(a), 0.6 * s * Math.sin(5 * a + c.t * 0.05),
                        (i % 3 == 0) ? 0xFF2A1A : 0x8A0A0A, 3.2);
            }
            int nn = c.n(22);
            for (int arm = 0; arm < 5; arm++) {
                for (int j = 0; j < nn; j++) {
                    double rho = M.frac((double) j / nn - c.t * 0.006 + arm * 0.013);
                    double th = arm * 2 * Math.PI / 5 + (1 - rho) * 5.5 + c.t * 0.012;
                    c.dust(B * 0.92 * rho * Math.cos(th), A * 0.92 * rho * Math.sin(th),
                            0.8 * s * rho * Math.sin(th * 2 + c.t * 0.1),
                            M.lerp(0x1A0000, 0xFF3A24, rho), 2.0 + rho * 1.4);
                }
            }
            long b = c.t / 6;
            for (int k = 0; k < 14; k++) {
                Random r = new Random(b * 131 + k * 7919L);
                double a = 2 * Math.PI * k / 14 + r.nextDouble() * 0.3;
                double px = B * Math.cos(a), py = A * Math.sin(a), pz = 0;
                double dx = Math.cos(a), dy = Math.sin(a);
                for (int i = 0; i < 12; i++) {
                    px += dx * 1.1 * s + r.nextGaussian() * 0.6 * s;
                    py += dy * 1.1 * s + r.nextGaussian() * 0.6 * s;
                    pz += r.nextGaussian() * 0.8 * s;
                    c.dust(px, py, pz, 0xFF2A2A, 1.8);
                    if (i % 3 == 0) c.p(Particle.ELECTRIC_SPARK, px, py, pz, 1, 0.1, 0);
                }
            }
            c.p(Particle.ASH, 0, 0, 0, 50, 14 * s, 0);
            c.p(Particle.CRIMSON_SPORE, 0, 0, 0, 25, 16 * s, 0);
        }
    }

    // ---------------------------------------------------------------- 3. ТОРНАДО
    public static final class Tornado implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, H = 60 * s;
            int n = c.n(48);
            for (int l = 0; l < n; l++) {
                double f = (double) l / n;
                double h = f * H, r = (2 + 16 * Math.pow(f, 1.3)) * s;
                for (int m = 0; m < 5; m++) {
                    double a = l * 0.45 + m * 2 * Math.PI / 5 + c.t * (0.22 - 0.1 * f);
                    int col = M.lerp(0x3A3A3A, 0xC8C8C8, ((l * 7 + m * 3) % 5) / 4.0);
                    c.dust(r * Math.cos(a), h, r * Math.sin(a), col, 2.6 + f);
                }
            }
            for (int k = 0; k < 10; k++) {
                double f = M.frac(k * 0.37 + c.t * 0.01);
                double r = (2 + 16 * Math.pow(f, 1.3)) * s * 1.1, a = k * 2.4 + c.t * 0.2;
                c.p(Particle.CLOUD, r * Math.cos(a), f * H, r * Math.sin(a), 1, 0.3, 0.01);
            }
            c.p(Particle.LARGE_SMOKE, 0, 0.5, 0, 4, 3 * s, 0.02);
        }
    }

    // ---------------------------------------------------------------- 4. ДНК
    public static final class Dna implements Fx {
        @Override
        public void tick(Ctx c) {
            double H = 70 * c.s, R = 7 * c.s;
            c.yaw = c.t * 0.004;
            int n = c.n(150);
            for (int i = 0; i < n; i++) {
                double f = (double) i / n, y = f * H;
                double a = f * 7 * 2 * Math.PI + c.t * 0.05;
                for (int k = 0; k < 2; k++) {
                    double ang = a + k * Math.PI;
                    c.trans(R * Math.cos(ang), y, R * Math.sin(ang),
                            k == 0 ? GREEN : YELLOW, k == 0 ? YELLOW : GREEN, 3.4);
                }
                if (i % 6 == 0) {
                    for (int m = 1; m <= 5; m++) {
                        double q = m / 6.0;
                        c.dust(R * Math.cos(a) * (1 - 2 * q), y, R * Math.sin(a) * (1 - 2 * q), 0xDFFFD0, 1.8);
                    }
                }
            }
            for (int k = 0; k < 3; k++) {
                double f = M.frac(c.t * 0.006 + k / 3.0);
                double a = f * 14 * Math.PI + c.t * 0.05;
                c.p(Particle.END_ROD, R * Math.cos(a), f * H, R * Math.sin(a), 1, 0, 0);
            }
        }
    }

    // ---------------------------------------------------------------- 5. ЧЁРНАЯ ДЫРА
    public static final class Hole implements Fx {
        static final int N = 800;
        final double[] ph = new double[N], th0 = new double[N], sp = new double[N], yo = new double[N];
        final double[][] hz = M.fib(120);

        public Hole() {
            Random r = new Random(9);
            for (int i = 0; i < N; i++) {
                ph[i] = r.nextDouble();
                th0[i] = r.nextDouble() * 2 * Math.PI;
                sp[i] = 0.7 + r.nextDouble() * 0.6;
                yo[i] = r.nextGaussian();
            }
        }

        @Override
        public void tick(Ctx c) {
            double S = c.s, Rin = 7 * S, Rout = 34 * S;
            c.oy = 38 * S;
            double T = 0.45, ct = Math.cos(T), st = Math.sin(T);
            for (int i = 0; i < N; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                double f = M.frac(ph[i] + c.t * 0.0016 * sp[i]);
                double r = Rin + (Rout - Rin) * Math.pow(1 - f, 1.8);
                double th = th0[i] + 16 * Math.pow(f, 1.6);
                double x = r * Math.cos(th), z = r * Math.sin(th), y = yo[i] * r * 0.05;
                double heat = 1 - (r - Rin) / (Rout - Rin);
                int col = heat > 0.6 ? M.lerp(0xFFB347, 0xFFFFFF, (heat - 0.6) / 0.4) : M.lerp(0xB02000, 0xFFB347, heat / 0.6);
                c.dust(x, y * ct - z * st, y * st + z * ct, col, Math.min(3.8, 2.0 + heat * 2));
            }
            for (int i = 0; i < 100; i++) {
                double a = 2 * Math.PI * i / 100 + c.t * 0.03, r = Rin * 1.12;
                double x = r * Math.cos(a), z = r * Math.sin(a);
                c.dust(x, -z * st, z * ct, 0xFFFFFF, 2.6);
            }
            for (int i = 0; i < hz.length; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                c.dust(hz[i][0] * 4.5 * S, hz[i][1] * 4.5 * S, hz[i][2] * 4.5 * S, 0x050505, 3.8);
            }
            for (int k = 0; k < 8; k++) {
                double f = M.frac(k / 8.0 + c.t * 0.012);
                double yy = f * 42 * S, rad = 0.8 * S + 0.08 * yy;
                int col = M.lerp(0xBFE0FF, 0x3050FF, f);
                for (int sg = -1; sg <= 1; sg += 2) {
                    double Y = sg * yy;
                    c.cloud(0, Y * ct, Y * st, col, 2.8, 5, rad);
                }
            }
        }
    }

    // ---------------------------------------------------------------- 6. ФЕНИКС
    public static final class Phoenix implements Fx {
        final double[][] body = M.fib(110);

        @Override
        public void tick(Ctx c) {
            double s = c.s, ang = c.t * 0.012, Ro = 24 * s;
            c.ox = Ro * Math.cos(ang);
            c.oz = Ro * Math.sin(ang);
            c.oy = 34 * s + 3 * s * Math.sin(c.t * 0.05);
            c.yaw = -ang;
            double flap = 0.75 * Math.sin(c.t * 0.09);
            int F = 11, nn = c.n(14);
            for (int sg = -1; sg <= 1; sg += 2) {
                for (int i = 0; i < F; i++) {
                    double beta = -0.25 + i * 0.115;
                    double len = 19 * s * (0.7 + 0.3 * Math.sin(Math.PI * (i + 1.5) / (F + 1.0)));
                    double dx = Math.cos(beta), dz = -Math.sin(beta);
                    for (int j = 1; j <= nn; j++) {
                        double q = (double) j / nn;
                        double x = sg * len * q * dx, z = len * q * dz + s;
                        double y = 0.22 * len * q * q * Math.sin(c.t * 0.09 - 1.0);
                        double fa = sg * flap;
                        double x2 = x * Math.cos(fa) - y * Math.sin(fa), y2 = x * Math.sin(fa) + y * Math.cos(fa);
                        c.dust(x2, y2, z, M.lerp(0xFFF0A0, q > 0.6 ? 0xE01800 : 0xFF7A00, q), 3.4 - 1.2 * q);
                        if (j == nn && i % 2 == 0) c.p(Particle.FLAME, x2, y2, z, 1, 0.2, 0.01);
                    }
                }
            }
            for (int i = 0; i < body.length; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                c.dust(body[i][0] * 1.5 * s, body[i][1] * 1.5 * s, body[i][2] * 5 * s,
                        (i & 1) == 0 ? 0xFFB000 : 0xFF6A00, 3.0);
            }
            for (int i = 0; i < 30; i++) {
                c.dust(body[i][0] * 1.2 * s, body[i][1] * 1.2 * s + 0.4 * s, 7.2 * s + body[i][2] * 1.2 * s, 0xFFE070, 2.6);
            }
            for (int m = 0; m < 4; m++) c.dust(0, 0.2 * s, 8.6 * s + m * 0.4 * s, 0xFF3000, 2.0);
            int nt = c.n(16);
            for (int k = 0; k < 5; k++) {
                for (int j = 0; j < nt; j++) {
                    double q = (double) j / nt;
                    double z = -5 * s - q * 26 * s;
                    double x = (k - 2) * (0.8 + q * 3) * s + 2.2 * s * q * Math.sin(q * 6 - c.t * 0.1);
                    double y = 1.5 * s * q * Math.sin(q * 5 - c.t * 0.08 + k) - 1.0 * s * q * q;
                    c.dust(x, y, z, M.lerp(0xFFD040, 0xC01000, q), 3.2 - 1.6 * q);
                }
            }
            c.p(Particle.FLAME, 0, 0, -6 * s, 5, 1.8 * s, 0.02);
        }
    }

    // ---------------------------------------------------------------- 7. СВЕРХНОВАЯ
    public static final class Supernova implements Fx {
        final double[][] F = M.fib(300);

        @Override
        public void tick(Ctx c) {
            double S = c.s;
            c.oy = 40 * S;
            int p = c.t % 420;
            if (p < 130) {
                double f = p / 130.0, r = (34 * (1 - f) * (1 - f) + 1.5) * S;
                c.yaw = c.t * 0.02;
                int col = M.lerp(0x6FA8FF, 0xFFFFFF, f);
                for (int i = 0; i < F.length; i++) {
                    if (((i + c.frame) & 1) != 0) continue;
                    c.dust(F[i][0] * r, F[i][1] * r, F[i][2] * r, col, 2 + f * 1.5);
                }
            } else if (p < 145) {
                c.cloud(0, 0, 0, 0xFFFFFF, 4, 60, 3 * S);
                c.p(Particle.END_ROD, 0, 0, 0, 80, 4 * S, 0.4);
            } else {
                double q = p - 145, Rmax = 50 * S;
                for (int k = 0; k < 3; k++) {
                    double r = (q - k * 16) * 0.18 * S;
                    if (r <= 0 || r > Rmax) continue;
                    double fade = 1 - r / Rmax;
                    int col = k == 0 ? M.lerp(0xFFF1B0, 0xFF6A00, r / Rmax)
                            : k == 1 ? M.lerp(0xFF8A00, 0x8A1010, r / Rmax)
                            : M.lerp(0xB070FF, 0x3040A0, r / Rmax);
                    c.yaw = k * 1.1 + q * 0.004;
                    for (int i = 0; i < F.length; i++) {
                        if (((i + c.frame) & 1) != 0) continue;
                        c.dust(F[i][0] * r, F[i][1] * r, F[i][2] * r, col, 3.5 * (0.5 + 0.5 * fade));
                    }
                }
                double rr = q * 0.18 * S * 1.15;
                c.yaw = 0;
                if (rr < Rmax) {
                    for (int i = 0; i < 120; i++) {
                        double a = 2 * Math.PI * i / 120;
                        c.dust(rr * Math.cos(a), 0, rr * Math.sin(a), 0xFFD060, 2.6);
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- 8. ГРОЗА
    public static final class Storm implements Fx {
        static final int N = 560, RN = 170;
        final double[] cxu = new double[N], czu = new double[N], cyu = new double[N], sh = new double[N];
        final double[] rx = new double[RN], rz = new double[RN], ro = new double[RN];

        public Storm() {
            Random r = new Random(5);
            for (int i = 0; i < N; i++) {
                double rr = Math.sqrt(r.nextDouble()), a = r.nextDouble() * 2 * Math.PI;
                cxu[i] = rr * Math.cos(a);
                czu[i] = rr * Math.sin(a);
                cyu[i] = r.nextGaussian() * 0.05 + 0.06 * (1 - rr);
                sh[i] = r.nextDouble();
            }
            for (int i = 0; i < RN; i++) {
                double rr = Math.sqrt(r.nextDouble()) * 0.9, a = r.nextDouble() * 2 * Math.PI;
                rx[i] = rr * Math.cos(a);
                rz[i] = rr * Math.sin(a);
                ro[i] = r.nextDouble();
            }
        }

        static List<double[]> bolt(Random r, double[] a, double[] b, double disp) {
            List<double[]> pts = new ArrayList<>();
            pts.add(a);
            pts.add(b);
            for (int it = 0; it < 5; it++) {
                List<double[]> nx = new ArrayList<>();
                for (int i = 0; i < pts.size() - 1; i++) {
                    double[] p = pts.get(i), q = pts.get(i + 1);
                    nx.add(p);
                    nx.add(new double[]{(p[0] + q[0]) / 2 + r.nextGaussian() * disp, (p[1] + q[1]) / 2,
                            (p[2] + q[2]) / 2 + r.nextGaussian() * disp});
                }
                nx.add(pts.get(pts.size() - 1));
                pts = nx;
                disp *= 0.55;
            }
            return pts;
        }

        static void line(Ctx c, double[] p, double[] q, double step, int col, double size) {
            double dx = q[0] - p[0], dy = q[1] - p[1], dz = q[2] - p[2];
            double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
            int n = Math.max(1, (int) (len / step));
            for (int i = 0; i <= n; i++) {
                double f = (double) i / n;
                c.dust(p[0] + dx * f, p[1] + dy * f, p[2] + dz * f, col, size);
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s, Hc = 40 * s, Rc = 36 * s;
            c.yaw = c.t * 0.003;
            for (int i = 0; i < N; i++) {
                if (((i + c.frame) & 1) != 0) continue;
                c.dust(cxu[i] * Rc, Hc + cyu[i] * Rc, czu[i] * Rc, M.lerp(0x202428, 0x707880, sh[i]), 3.8);
            }
            for (int i = 0; i < c.n(RN); i++) {
                double y = Hc - M.frac(ro[i] + c.t * 0.035) * Hc;
                c.dust(rx[i] * Rc, y, rz[i] * Rc, 0x7FA8FF, 1.0);
            }
            c.yaw = 0;
            long b = c.t / 8;
            Random rb = new Random(b * 7919L + 17);
            if (rb.nextInt(3) == 0) {
                double[] a = {rb.nextGaussian() * 0.35 * Rc, Hc - s, rb.nextGaussian() * 0.35 * Rc};
                double[] g = {a[0] + rb.nextGaussian() * 8 * s, 0.2, a[2] + rb.nextGaussian() * 8 * s};
                List<double[]> pts = bolt(rb, a, g, 7 * s);
                for (int i = 0; i < pts.size() - 1; i++) {
                    line(c, pts.get(i), pts.get(i + 1), 0.9, 0xFFFFFF, 2.2);
                    if (i % 3 == 0) {
                        double[] p = pts.get(i);
                        c.p(Particle.ELECTRIC_SPARK, p[0], p[1], p[2], 1, 0.2, 0.05);
                    }
                }
                for (int k = 0; k < 3; k++) {
                    double[] st = pts.get(4 + rb.nextInt(pts.size() - 8));
                    double[] en = {st[0] + rb.nextGaussian() * 10 * s, Math.max(0.2, st[1] - (10 + rb.nextDouble() * 12) * s),
                            st[2] + rb.nextGaussian() * 10 * s};
                    List<double[]> br = bolt(rb, st, en, 3 * s);
                    for (int i = 0; i < br.size() - 1; i++) line(c, br.get(i), br.get(i + 1), 1.0, 0x9FC0FF, 1.5);
                }
                c.p(Particle.ELECTRIC_SPARK, g[0], 0.5, g[2], 25, 2.5 * s, 0.25);
                c.cloud(g[0], 0.5, g[2], 0xFFFFFF, 3, 6, 1.2 * s);
            }
        }
    }

    // ---------------------------------------------------------------- 9. ТРЕФОИЛ-УЗЕЛ
    public static final class Knot implements Fx {
        static double[] P(double th, double k) {
            return new double[]{k * (Math.sin(th) + 2 * Math.sin(2 * th)),
                    k * (Math.cos(th) - 2 * Math.cos(2 * th)), k * (-Math.sin(3 * th))};
        }

        @Override
        public void tick(Ctx c) {
            double k = 9 * c.s;
            c.oy = 32 * c.s;
            c.yaw = c.t * 0.006;
            int n = c.n(200);
            for (int j = 0; j < n; j++) {
                double u = M.frac((double) j / n + c.t * 0.0025), th = u * 2 * Math.PI;
                double[] p = P(th, k);
                double[] T = M.norm(M.sub(P(th + 0.01, k), P(th - 0.01, k)));
                double d = M.dot(p, T);
                double[] N = M.norm(new double[]{p[0] - T[0] * d, p[1] - T[1] * d, p[2] - T[2] * d});
                double[] B = M.cross(T, N);
                int col = M.hsv(M.frac(u * 2 + c.t * 0.004), 0.85, 1.0);
                for (int st = 0; st < 3; st++) {
                    double al = 2 * Math.PI * st / 3 + th * 3 + c.t * 0.03, rr = 2.0 * c.s;
                    double cs = Math.cos(al), sn = Math.sin(al);
                    c.dust(p[0] + rr * (cs * N[0] + sn * B[0]), p[1] + rr * (cs * N[1] + sn * B[1]),
                            p[2] + rr * (cs * N[2] + sn * B[2]), col, 3.2);
                }
            }
        }
    }

    // ---------------------------------------------------------------- 10. СЕВЕРНОЕ СИЯНИЕ
    public static final class Aurora implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            c.oy = 46 * s;
            int cols = c.n(54);
            for (int cu = 0; cu < 2; cu++) {
                for (int i = 0; i < cols; i++) {
                    if (((i + cu + c.frame) & 1) != 0) continue;
                    double f = (double) i / (cols - 1), xx = (f - 0.5) * 96 * s;
                    double z = cu * 30 * s + 12 * s * Math.sin(xx / (11 * s) + c.t * 0.01 + cu * 2)
                            + 5 * s * Math.sin(xx / (5 * s) - c.t * 0.017);
                    double hh = (17 + 9 * Math.sin(xx / (9 * s) + c.t * 0.013 + cu) + 4 * Math.sin(xx / (4 * s) - c.t * 0.02)) * s;
                    int ns = c.n(10);
                    for (int k = 0; k < ns; k++) {
                        double q = ns == 1 ? 0 : (double) k / (ns - 1);
                        int col = q < 0.5 ? M.lerp(0x4DFF8A, 0x24E0C8, q * 2) : M.lerp(0x24E0C8, 0xA060FF, (q - 0.5) * 2);
                        if (cu == 1) col = M.lerp(col, 0xFF70C0, 0.35);
                        c.dust(xx, q * hh, z, col, 3.8 - 1.6 * q);
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- 11. РОЙ ПОЛОСОК (как на скриншотах)
    /** Тысячи коротких зелёно-жёлтых полосок-следов, медленно и хаотично плывущих по огромному небу. */
    public static final class Swarm implements Fx {
        static final int N = 400, T = 10;
        final double[][] home = new double[N][], a = new double[N][18];
        final double[] mix = new double[N];

        public Swarm() {
            Random r = new Random(4242);
            for (int i = 0; i < N; i++) {
                double[] d = M.norm(new double[]{r.nextGaussian(), r.nextGaussian(), r.nextGaussian()});
                double rad = 80 * Math.cbrt(r.nextDouble());
                home[i] = new double[]{d[0] * rad, d[1] * rad * 0.7, d[2] * rad};
                for (int k = 0; k < 3; k++) {
                    a[i][k * 6] = 8 + r.nextDouble() * 12;
                    a[i][k * 6 + 1] = 0.0015 + r.nextDouble() * 0.0025;
                    a[i][k * 6 + 2] = r.nextDouble() * 2 * Math.PI;
                    a[i][k * 6 + 3] = 5 + r.nextDouble() * 7;
                    a[i][k * 6 + 4] = 0.003 + r.nextDouble() * 0.004;
                    a[i][k * 6 + 5] = r.nextDouble() * 2 * Math.PI;
                }
                mix[i] = r.nextDouble();
            }
        }

        private double pos(int i, int k, double tt, double s) {
            double[] q = a[i];
            return s * (home[i][k] + q[k * 6] * Math.sin(q[k * 6 + 1] * tt + q[k * 6 + 2])
                    + q[k * 6 + 3] * Math.sin(q[k * 6 + 4] * tt + q[k * 6 + 5]));
        }

        @Override
        public void tick(Ctx c) {
            c.oy = 60 * c.s;
            int tl = c.n(T);
            for (int i = 0; i < N; i++) {
                int from = M.lerp(GREEN, YELLOW, mix[i]), to = M.lerp(YELLOW, GREEN, mix[i]);
                for (int j = 0; j < tl; j++) {
                    double tt = c.t - j * 12.0;
                    c.trans(pos(i, 0, tt, c.s), pos(i, 1, tt, c.s), pos(i, 2, tt, c.s), from, to, 3.0 - 1.6 * j / tl);
                }
            }
        }
    }
}

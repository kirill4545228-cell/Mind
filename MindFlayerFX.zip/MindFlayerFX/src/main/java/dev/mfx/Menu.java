package dev.mfx;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Меню выбора эффекта: /mfx или /mfx menu. Клик по предмету запускает анимацию в вашей точке. */
public final class Menu implements Listener {
    static final int PER = 45;
    static final double[] SCALES = {0.5, 1, 1.5, 2, 3, 4};
    static final int[] SECS = {0, 60, 300, 600};

    static final class Holder implements InventoryHolder {
        int page;
        Inventory inv;

        @Override
        public Inventory getInventory() { return inv; }
    }

    private static final Map<String, Material> ICONS = new HashMap<>();

    static {
        String[][] m = {
                {"sphere", "SLIME_BALL"}, {"mindflayer", "ENDER_EYE"}, {"galaxy", "NETHER_STAR"}, {"rift", "CRYING_OBSIDIAN"},
                {"tornado", "FEATHER"}, {"dna", "VINE"}, {"blackhole", "OBSIDIAN"}, {"phoenix", "BLAZE_POWDER"},
                {"supernova", "FIREWORK_STAR"}, {"storm", "LIGHTNING_ROD"}, {"knot", "CHAIN"}, {"swarm", "GLOW_BERRIES"},
                {"eye", "SPIDER_EYE"}, {"reaper", "NETHERITE_HOE"}, {"bloodrain", "REDSTONE"}, {"souls", "SOUL_LANTERN"},
                {"skull", "SKELETON_SKULL"}, {"claw", "BONE"}, {"tentacles", "KELP"}, {"pentagram", "REDSTONE_TORCH"},
                {"meteors", "FIRE_CHARGE"}, {"ghosts", "GHAST_TEAR"}, {"nuke", "TNT"}, {"dragon", "DRAGON_HEAD"},
                {"crows", "BLACK_DYE"}, {"bloodmoon", "RED_DYE"}, {"maw", "IRON_BARS"}, {"web", "COBWEB"},
                {"plasma", "END_CRYSTAL"}, {"obelisk", "ECHO_SHARD"}, {"summon", "ENCHANTED_BOOK"}, {"inferno", "LAVA_BUCKET"},
                {"watchers", "FERMENTED_SPIDER_EYE"}, {"chains", "CHAIN"}, {"banshee", "PHANTOM_MEMBRANE"},
                {"heart", "RED_CANDLE"}, {"eclipse", "COAL"}, {"aurora", "AMETHYST_SHARD"},
                {"hand", "BONE_MEAL"}, {"skycrack", "GLASS_PANE"}, {"graveyard", "MOSSY_COBBLESTONE"}, {"gallows", "LEAD"},
                {"centipede", "ROTTEN_FLESH"}, {"cult", "WITHER_SKELETON_SKULL"}, {"hellgate", "MAGMA_CREAM"},
                {"demon", "NETHERRACK"}, {"slender", "BLACK_CONCRETE"}, {"creepfog", "GRAY_DYE"}, {"seraph", "ELYTRA"},
                {"serpent", "GREEN_DYE"}, {"doomclock", "CLOCK"}, {"blacksun", "BLACK_GLAZED_TERRACOTTA"},
                {"brain", "PINK_DYE"}, {"deadtree", "DEAD_BUSH"}, {"ribcage", "BONE_BLOCK"}, {"swordrain", "NETHERITE_SWORD"},
                {"plague", "POISONOUS_POTATO"}, {"hypno", "PURPLE_DYE"}, {"cage", "IRON_BARS"}, {"howl", "WOLF_SPAWN_EGG"},
                {"horseman", "SADDLE"}, {"bloodriver", "REDSTONE_BLOCK"}, {"wendigo", "BONE_MEAL"},
                {"bloodswarm", "CRIMSON_FUNGUS"}, {"ashswarm", "GUNPOWDER"}, {"voidswarm", "ENDER_PEARL"}, {"greenorb", "LIME_DYE"}
        };
        for (String[] e : m) {
            Material mat = Material.matchMaterial(e[1]);
            if (mat != null) ICONS.put(e[0], mat);
        }
    }

    private final MfxPlugin pl;
    private final Map<UUID, Integer> scaleIdx = new HashMap<>(), secIdx = new HashMap<>();

    public Menu(MfxPlugin pl) { this.pl = pl; }

    static Component t(String s, NamedTextColor c) {
        return Component.text(s, c).decoration(TextDecoration.ITALIC, false);
    }

    static ItemStack item(Material m, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta im = it.getItemMeta();
        im.displayName(name);
        if (lore != null) im.lore(lore);
        it.setItemMeta(im);
        return it;
    }

    static List<Component> wrap(String text, int width, NamedTextColor col) {
        List<Component> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String w : text.split(" ")) {
            if (line.length() + w.length() + 1 > width && line.length() > 0) {
                out.add(t(line.toString(), col));
                line.setLength(0);
            }
            if (line.length() > 0) line.append(' ');
            line.append(w);
        }
        if (line.length() > 0) out.add(t(line.toString(), col));
        return out;
    }

    private double scaleOf(Player p) { return SCALES[scaleIdx.getOrDefault(p.getUniqueId(), 1)]; }

    private int secOf(Player p) { return SECS[secIdx.getOrDefault(p.getUniqueId(), 0)]; }

    public void open(Player p, int page) {
        List<MfxPlugin.Def> defs = new ArrayList<>(MfxPlugin.DEFS.values());
        int pages = Math.max(1, (defs.size() + PER - 1) / PER);
        page = Math.max(0, Math.min(page, pages - 1));
        Holder h = new Holder();
        h.page = page;
        Inventory inv = Bukkit.createInventory(h, 54, Component.text("Эффекты MindFlayerFX  " + (page + 1) + "/" + pages));
        h.inv = inv;
        for (int i = 0; i < PER; i++) {
            int idx = page * PER + i;
            if (idx >= defs.size()) break;
            MfxPlugin.Def d = defs.get(idx);
            List<Component> lore = wrap(d.desc(), 34, NamedTextColor.GRAY);
            lore.add(Component.empty());
            lore.add(t("Клик — запустить у вас", NamedTextColor.YELLOW));
            inv.setItem(i, item(ICONS.getOrDefault(d.id(), Material.PAPER), t(d.id(), NamedTextColor.GREEN), lore));
        }
        ItemStack glass = item(Material.BLACK_STAINED_GLASS_PANE, t(" ", NamedTextColor.BLACK), null);
        for (int i = 45; i < 54; i++) inv.setItem(i, glass);
        if (page > 0) inv.setItem(45, item(Material.ARROW, t("← Назад", NamedTextColor.YELLOW), null));
        if (page < pages - 1) inv.setItem(53, item(Material.ARROW, t("Вперёд →", NamedTextColor.YELLOW), null));
        inv.setItem(47, item(Material.SPYGLASS, t("Масштаб: " + scaleOf(p), NamedTextColor.AQUA),
                List.of(t("Клик — сменить", NamedTextColor.GRAY))));
        inv.setItem(49, item(Material.BARRIER, t("Остановить все", NamedTextColor.RED), null));
        int sec = secOf(p);
        inv.setItem(51, item(Material.CLOCK, t("Длительность: " + (sec == 0 ? "бесконечно" : sec + " с"), NamedTextColor.AQUA),
                List.of(t("Клик — сменить", NamedTextColor.GRAY))));
        p.openInventory(inv);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        if (!p.hasPermission("mfx.use")) return;
        int slot = e.getSlot();
        if (slot < PER) {
            int idx = h.page * PER + slot;
            List<MfxPlugin.Def> defs = new ArrayList<>(MfxPlugin.DEFS.values());
            if (idx >= defs.size()) return;
            p.closeInventory();
            pl.launch(p, defs.get(idx), scaleOf(p), secOf(p));
        } else if (slot == 45 && h.page > 0) {
            open(p, h.page - 1);
        } else if (slot == 53 && e.getCurrentItem() != null && e.getCurrentItem().getType() == Material.ARROW) {
            open(p, h.page + 1);
        } else if (slot == 47) {
            scaleIdx.put(p.getUniqueId(), (scaleIdx.getOrDefault(p.getUniqueId(), 1) + 1) % SCALES.length);
            open(p, h.page);
        } else if (slot == 51) {
            secIdx.put(p.getUniqueId(), (secIdx.getOrDefault(p.getUniqueId(), 0) + 1) % SECS.length);
            open(p, h.page);
        } else if (slot == 49) {
            pl.stopAllPublic();
            p.sendMessage("§aВсе анимации остановлены.");
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}

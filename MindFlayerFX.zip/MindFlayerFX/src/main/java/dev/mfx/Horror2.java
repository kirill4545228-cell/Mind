package dev.mfx;

import org.bukkit.Particle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Ещё 25 хоррорных, эпичных и ДОЛГИХ анимаций.
 * Большинство работает циклами по 30-90 секунд: медленное нарастание, кульминация, затишье.
 */
public final class Horror2 {
    private Horror2() {}

    // ------------------------------------------------------------ помощники
    static double sm(double x) {
        x = M.clamp(x, 0, 1);
        return x * x * (3 - 2 * x);
    }

    static void L(Ctx c, double x1, double y1, double z1, double x2, double y2, double z2, int col, double sz) {
        Horror.ln(c, x1, y1, z1, x2, y2, z2, 1.0, col, sz);
    }

    static boolean inPoly(double[][] p, double x, double y) {
        boolean in = false;
        for (int i = 0, j = p.length - 1; i < p.length; j = i++) {
            if ((p[i][1] > y) != (p[j][1] > y)
                    && x < (p[j][0] - p[i][0]) * (y - p[i][1]) / (p[j][1] - p[i][1]) + p[i][0]) in = !in;
        }
        return in;
    }

    /** Фигура со своей системой координат: side (вбок), up (вверх), fwd (вперёд). Всё в единицах масштаба. */
    static final class Rig {
        double bx, by, bz, fx, fz, gx, gz, s;

        void set(double bx, double by, double bz, double facing, double s) {
            this.bx = bx; this.by = by; this.bz = bz; this.s = s;
            fx = Math.cos(facing); fz = Math.sin(facing);
            gx = -fz; gz = fx;
        }

        double X(double side, double fwd) { return bx + (gx * side + fx * fwd) * s; }

        double Z(double side, double fwd) { return bz + (gz * side + fz * fwd) * s; }

        double Y(double up) { return by + up * s; }

        void D(Ctx c, double side, double up, double fwd, int col, double sz) {
            c.dust(X(side, fwd), Y(up), Z(side, fwd), col, sz);
        }

        void L(Ctx c, double s1, double u1, double f1, double s2, double u2, double f2, int col, double sz) {
            Horror.ln(c, X(s1, f1), Y(u1), Z(s1, f1), X(s2, f2), Y(u2), Z(s2, f2), 1.0, col, sz);
        }

        void P(Ctx c, Particle p, double side, double up, double fwd, int n, double sp, double sv) {
            c.p(p, X(side, fwd), Y(up), Z(side, fwd), n, sp * s, sv);
        }

        void C(Ctx c, double side, double up, double fwd, int col, double sz, int n, double sp) {
            c.cloud(X(side, fwd), Y(up), Z(side, fwd), col, sz, n, sp * s);
        }
    }

    // ------------------------------------------------------------ 1. РУКА ИЗ-ПОД ЗЕМЛИ
    public static final class Hand implements Fx {
        static final double[] FL = {4.2, 5.6, 6.2, 5.6, 4.2};

        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 1400, u = (c.t % P) / P;
            double rise = sm(u / 0.2), fall = u > 0.92 ? sm((u - 0.92) / 0.08) : 0;
            double h = rise * (1 - fall) * 16 * s;
            double curl;
            if (u < 0.6) curl = 0.15 + 0.1 * Math.sin(c.t * 0.02);
            else if (u < 0.9) curl = 0.15 + 1.5 * sm((u - 0.6) / 0.3);
            else curl = 1.65;
            c.yaw = c.t * 0.001;
            for (int k = 0; k < 8; k++) {
                double a = 2 * Math.PI * k / 8 + 0.3, r = (6 + 14 * rise) * s;
                L(c, 3 * s * Math.cos(a), 0.1, 3 * s * Math.sin(a), r * Math.cos(a), 0.1, r * Math.sin(a), 0x2A0A0A, 2.4);
            }
            c.p(Particle.LARGE_SMOKE, 0, 0.3, 0, 1, 4 * s, 0.02);
            if (u > 0.9 && u < 0.97) {
                double r = (u - 0.9) / 0.07 * 40 * s;
                Horror.ring(c, 0, 0.3, 0, r, c.n(70), 0, 0xFF2020, 3.0);
            }
            if (h < 0.5) return;
            L(c, -1.2 * s, 0, 0, -1.2 * s, h, 0, 0xDCD3B8, 2.4);
            L(c, 1.2 * s, 0, 0, 1.2 * s, h, 0, 0xCFC6AA, 2.4);
            double top = h + 7 * s;
            for (double z = -4 * s; z <= 4 * s; z += 1.4 * s) {
                for (double y = h; y <= top; y += 1.4 * s) {
                    if (((int) (z / s) + (int) (y / s) + c.frame & 1) == 0) c.dust(0.3 * s, y, z, 0x9A9078, 2.0);
                }
            }
            for (int i = 0; i < 5; i++) {
                double z = (-3.4 + 1.7 * i) * s, x = 0.5 * s, y = top, ph = 0;
                for (int sg = 0; sg < 3; sg++) {
                    ph += curl * (0.7 + 0.3 * sg) * 0.6;
                    double len = FL[i] * s * 0.8, nx = x + len * Math.sin(ph), ny = y + len * Math.cos(ph);
                    L(c, x, y, z, nx, ny, z, 0xE8E0C8, 2.3);
                    c.dust(nx, ny, z, 0xFFFFF0, 3.0);
                    x = nx;
                    y = ny;
                }
                if (i % 2 == 0 && c.frame % 2 == 0) c.p(Particle.SOUL, x, y, z, 1, 0.5 * s, 0.01);
            }
            double tz = 4.2 * s, tx = 0.5 * s, ty = h + 1.5 * s, tph = 0.9;
            for (int sg = 0; sg < 2; sg++) {
                tph -= curl * 0.5;
                double len = 4.5 * s, nz = tz + len * Math.sin(tph), ny = ty + len * Math.cos(tph);
                L(c, tx, ty, tz, tx, ny, nz, 0xE8E0C8, 2.3);
                c.dust(tx, ny, nz, 0xFFFFF0, 3.0);
                tz = nz;
                ty = ny;
            }
        }
    }

    // ------------------------------------------------------------ 2. ТРЕЩИНА В НЕБЕ
    public static final class SkyCrack implements Fx {
        final double[] jy = new double[41];

        public SkyCrack() {
            Random r = new Random(77);
            double y = 0;
            for (int i = 0; i < 41; i++) {
                jy[i] = y;
                y += (r.nextDouble() - 0.5) * 3;
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 1500, u = (c.t % P) / P;
            double open = sm(u / 0.3) * (1 - sm((u - 0.85) / 0.15));
            c.oy = 48 * s;
            c.yaw = 0.4;
            int n = c.n(40);
            for (int i = 0; i <= n; i++) {
                double f = (double) i / n, x = -32 * s + 64 * s * f;
                double y = jy[(int) (f * 40)] * s;
                double w = open * 7 * s * (1 - Math.pow(2 * f - 1, 2));
                c.dust(x, y + w, 0, 0x0A0008, 3.4);
                c.dust(x, y - w, 0, 0x0A0008, 3.4);
                if (w > 0.5 * s) {
                    for (double v = -w; v <= w; v += 1.3 * s) {
                        if (((i + (int) (v / s) + c.frame) & 1) == 0) {
                            c.dust(x, y + v, -0.1, M.lerp(0xFF2000, 0xFFB000, 1 - Math.abs(v) / w), 2.6);
                        }
                    }
                }
                if (i % 6 == 0 && open > 0.1) c.p(Particle.FLAME, x, y - w, 0, 1, 0.4 * s, 0.02);
            }
            if (open > 0.6) {
                double ry = 8 * s * open;
                for (int k = 0; k < 28; k++) {
                    double a = 2 * Math.PI * k / 28;
                    c.dust(3 * s * Math.cos(a), ry * Math.sin(a), -0.3, 0xFFD000, 3.2);
                }
                L(c, 0, -ry, -0.3, 0, ry, -0.3, 0x000000, 3.6);
            }
            if (open > 0.1) c.p(Particle.ASH, 0, -20 * s, 0, 8, 22 * s, 0);
        }
    }

    // ------------------------------------------------------------ 3. КЛАДБИЩЕ
    public static final class Graveyard implements Fx {
        static final int N = 18;
        final double[] gx = new double[N], gz = new double[N];

        public Graveyard() {
            Random r = new Random(5);
            for (int i = 0; i < N; i++) {
                double a = 2 * Math.PI * i / N + r.nextDouble() * 0.3, d = 8 + r.nextDouble() * 24;
                gx[i] = Math.cos(a) * d;
                gz[i] = Math.sin(a) * d;
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            for (int i = 0; i < N; i++) {
                double x = gx[i] * s, z = gz[i] * s, w = 1.3 * s, h = 3.2 * s;
                L(c, x - w, 0, z, x - w, h, z, 0x6E6E78, 2.4);
                L(c, x + w, 0, z, x + w, h, z, 0x6E6E78, 2.4);
                for (int k = 0; k <= 8; k++) {
                    double a = Math.PI * k / 8;
                    c.dust(x + w * Math.cos(a), h + w * Math.sin(a), z, 0x7C7C86, 2.4);
                }
                L(c, x, h * 0.5, z, x, h * 1.15, z, 0x303038, 2.0);
                L(c, x - 0.6 * s, h * 0.95, z, x + 0.6 * s, h * 0.95, z, 0x303038, 2.0);
                double hp = (c.t * 0.0035 + i * 0.37) % 1.0;
                double hh = sm(hp / 0.25) * (1 - sm((hp - 0.8) / 0.2)) * 5 * s;
                if (hh > 0.4) {
                    double hx = x + 2.2 * s, hz = z + 1.5 * s;
                    L(c, hx, 0, hz, hx, hh, hz, 0xDDD4BC, 2.2);
                    for (int f = 0; f < 5; f++) {
                        double an = -0.8 + 0.4 * f;
                        double fl = 2.2 * s * (0.6 + 0.4 * Math.sin(c.t * 0.05 + f));
                        L(c, hx, hh, hz, hx + Math.sin(an) * fl, hh + Math.cos(an) * fl, hz, 0xEFE8D2, 2.2);
                    }
                    if (c.frame % 4 == i % 4) c.p(Particle.SOUL, hx, hh, hz, 1, 0.6 * s, 0.02);
                }
                if (i % 3 == 0 && c.frame % 3 == 0) c.p(Particle.SOUL_FIRE_FLAME, x, h + 1.5 * s, z, 1, 0.3 * s, 0.01);
            }
            int n = c.n(70);
            for (int k = 0; k < n; k++) {
                double a = Horror.hash(k * 3.17) * 2 * Math.PI + c.t * 0.002 * (k % 2 == 0 ? 1 : -1);
                double d = (4 + Horror.hash(k * 7.31) * 38) * s;
                double y = (0.6 + 0.8 * Math.sin(c.t * 0.01 + k)) * s;
                c.cloud(Math.cos(a) * d, y, Math.sin(a) * d, (k & 1) == 0 ? 0x7A808C : 0x59606C, 3.2, 2, 2.2 * s);
            }
        }
    }

    // ------------------------------------------------------------ 4. ВИСЕЛИЦА
    public static final class Gallows implements Fx {
        static double[] at(double tx, double ty, double sn, double cs, double px, double py) {
            return new double[]{tx + sn * py + cs * px, ty - cs * py + sn * px};
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s, top = 24 * s;
            c.yaw = 0.5;
            L(c, -9 * s, 0, 0, -9 * s, top + 1.5 * s, 0, 0x3A2A1A, 3.2);
            L(c, -9 * s, 0, 0.5 * s, -9 * s, top + 1.5 * s, 0.5 * s, 0x2E2014, 3.2);
            L(c, -11 * s, top + 1.5 * s, 0, 31 * s, top + 1.5 * s, 0, 0x3A2A1A, 3.2);
            L(c, -9 * s, top - 6 * s, 0, -3 * s, top + 1.5 * s, 0, 0x2E2014, 3.0);
            for (int i = 0; i < 5; i++) {
                double x = (-1 + 7 * i) * s;
                double th = 0.14 * Math.sin(c.t * 0.018 + i * 1.7), sn = Math.sin(th), cs = Math.cos(th);
                double[] a0 = at(x, top, sn, cs, 0, 5 * s), a1 = at(x, top, sn, cs, 0, 7.6 * s);
                double[] hip = at(x, top, sn, cs, 0, 12.5 * s);
                L(c, x, top, 0, a0[0], a0[1], 0, 0x8A7040, 1.8);
                for (int k = 0; k < 10; k++) {
                    double an = 2 * Math.PI * k / 10;
                    double[] hp = at(x, top, sn, cs, 1.2 * s * Math.cos(an), 6.2 * s + 1.2 * s * Math.sin(an));
                    c.dust(hp[0], hp[1], 0, 0x0C0C0C, 3.0);
                }
                L(c, a1[0], a1[1], 0, hip[0], hip[1], 0, 0x1A1A1A, 3.4);
                double[] s1 = at(x, top, sn, cs, -1.5 * s, 7.8 * s), s2 = at(x, top, sn, cs, 1.5 * s, 7.8 * s);
                L(c, s1[0], s1[1], 0, s2[0], s2[1], 0, 0x1A1A1A, 3.2);
                double[] h1 = at(x, top, sn, cs, -1.8 * s, 12 * s), h2 = at(x, top, sn, cs, 1.8 * s, 12 * s);
                L(c, s1[0], s1[1], 0, h1[0], h1[1], 0, 0x1A1A1A, 2.6);
                L(c, s2[0], s2[1], 0, h2[0], h2[1], 0, 0x1A1A1A, 2.6);
                double[] f1 = at(x, top, sn, cs, -0.8 * s, 18 * s), f2 = at(x, top, sn, cs, 0.8 * s, 18 * s);
                L(c, hip[0], hip[1], 0, f1[0], f1[1], 0, 0x1A1A1A, 2.8);
                L(c, hip[0], hip[1], 0, f2[0], f2[1], 0, 0x1A1A1A, 2.8);
                if (c.t / 160 % 5 == i) {
                    double[] e1 = at(x, top, sn, cs, -0.45 * s, 6.4 * s), e2 = at(x, top, sn, cs, 0.45 * s, 6.4 * s);
                    c.dust(e1[0], e1[1], 0.9 * s, 0xFF0000, 3.9);
                    c.dust(e2[0], e2[1], 0.9 * s, 0xFF0000, 3.9);
                }
            }
            int n = c.n(30);
            for (int k = 0; k < n; k++) {
                double x = (-12 + 44 * Horror.hash(k * 1.7) + 2 * Math.sin(c.t * 0.01 + k)) * s;
                double z = (Horror.hash(k * 5.9) - 0.5) * 12 * s;
                c.cloud(x, 0.5 * s, z, 0x6A6A74, 3.0, 2, 2 * s);
            }
        }
    }

    // ------------------------------------------------------------ 5. ГИГАНТСКАЯ СТОНОЖКА
    public static final class Centipede implements Fx {
        static final int N = 42;

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            for (int i = 0; i < N; i++) {
                double a = c.t * 0.009 - i * 0.075, r = (22 + 7 * Math.sin(2.5 * a)) * s;
                double x = r * Math.cos(a), z = r * Math.sin(a);
                double a2 = a + 0.02, r2 = (22 + 7 * Math.sin(2.5 * a2)) * s;
                double dx = r2 * Math.cos(a2) - x, dz = r2 * Math.sin(a2) - z;
                double l = Math.max(1e-6, Math.hypot(dx, dz));
                dx /= l;
                dz /= l;
                double nx = -dz, nz = dx;
                double rad = (i == 0 ? 2.2 : 1.7 - 0.6 * i / N) * s;
                c.cloud(x, rad, z, (i & 1) == 0 ? 0x3A140C : 0x5A2414, 3.8, 5, rad * 0.5);
                double sw = Math.sin(c.t * 0.25 - i * 0.8);
                for (int sd = -1; sd <= 1; sd += 2) {
                    double tx = x + nx * sd * 3.2 * s + dx * sw * 1.2 * s, tz = z + nz * sd * 3.2 * s + dz * sw * 1.2 * s;
                    double mx = x + nx * sd * 2.2 * s, mz = z + nz * sd * 2.2 * s;
                    L(c, x, rad, z, mx, rad + 1.0 * s, mz, 0x8A4A20, 1.6);
                    L(c, mx, rad + 1.0 * s, mz, tx, 0.1, tz, 0x8A4A20, 1.6);
                }
                if (i % 5 == 0) c.p(Particle.ASH, x, 0.3, z, 1, 0.6 * s, 0.01);
                if (i == 0) {
                    for (int sd = -1; sd <= 1; sd += 2) {
                        c.dust(x + dx * 1.6 * s + nx * sd * 0.8 * s, rad + 0.7 * s, z + dz * 1.6 * s + nz * sd * 0.8 * s, 0xFF2000, 3.9);
                        L(c, x + dx * 1.8 * s + nx * sd * 0.5 * s, rad, z + dz * 1.8 * s + nz * sd * 0.5 * s,
                                x + dx * 3.6 * s + nx * sd * (0.4 + 0.5 * Math.sin(c.t * 0.2)) * s, rad, z + dz * 3.6 * s + nz * sd * (0.4 + 0.5 * Math.sin(c.t * 0.2)) * s, 0xD8C8A8, 2.4);
                        L(c, x + dx * 1.5 * s, rad + 1.2 * s, z + dz * 1.5 * s,
                                x + dx * 5 * s + nx * sd * 2 * s, rad + 3 * s + Math.sin(c.t * 0.1 + sd) * s, z + dz * 5 * s + nz * sd * 2 * s, 0x6A3A18, 1.6);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ 6. КУЛЬТ
    public static final class Cult implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 1600, u = (c.t % P) / P;
            double power = sm((u - 0.55) / 0.25) * (1 - sm((u - 0.92) / 0.08));
            Horror.ring(c, 0, 0.15, 0, 17 * s, c.n(120), c.t * 0.002, 0x7A1020, 2.4);
            Horror.ring(c, 0, 0.15, 0, 12.5 * s, c.n(90), -c.t * 0.002, 0x4A1060, 2.2);
            for (int tri = 0; tri < 2; tri++) {
                for (int e = 0; e < 3; e++) {
                    double a1 = tri * Math.PI / 3 + 2 * Math.PI * e / 3 + c.t * 0.002, a2 = a1 + 2 * Math.PI / 3;
                    L(c, 12.5 * s * Math.cos(a1), 0.15, 12.5 * s * Math.sin(a1), 12.5 * s * Math.cos(a2), 0.15, 12.5 * s * Math.sin(a2), 0x9A1830, 2.2);
                }
            }
            for (int i = 0; i < 12; i++) {
                double a = c.t * 0.003 + 2 * Math.PI * i / 12, x = 15 * s * Math.cos(a), z = 15 * s * Math.sin(a);
                double ix = -Math.cos(a), iz = -Math.sin(a), tx = -Math.sin(a), tz = Math.cos(a);
                for (int l = 0; l < 8; l++) {
                    double f = l / 7.0, rr = (1.7 * (1 - f) + 0.7 * f) * s, y = f * 6 * s;
                    for (int m = 0; m < 6; m++) {
                        double an = 2 * Math.PI * m / 6 + l;
                        c.dust(x + rr * Math.cos(an), y, z + rr * Math.sin(an), (l + m) % 2 == 0 ? 0x120818 : 0x1E1030, 2.8);
                    }
                }
                c.cloud(x, 6.8 * s, z, 0x0A0610, 3.2, 3, 0.5 * s);
                double ex = x + ix * 0.7 * s, ez = z + iz * 0.7 * s;
                int ec = power > 0.3 ? 0xFF2020 : 0xB0FFB0;
                c.dust(ex + tx * 0.35 * s, 6.9 * s, ez + tz * 0.35 * s, ec, 3.2);
                c.dust(ex - tx * 0.35 * s, 6.9 * s, ez - tz * 0.35 * s, ec, 3.2);
                double up = Math.min(1.3, 0.5 + 0.5 * Math.sin(c.t * 0.012 + i) + power);
                for (int sd = -1; sd <= 1; sd += 2) {
                    L(c, x + tx * sd * 1.2 * s, 5.2 * s, z + tz * sd * 1.2 * s,
                            x + tx * sd * 1.8 * s + ix * 0.8 * s, (5.2 + 2.6 * up) * s, z + tz * sd * 1.8 * s + iz * 0.8 * s, 0x1A1020, 2.4);
                }
            }
            c.p(Particle.FLAME, 0, 0.5 * s, 0, 5, 1.2 * s, 0.04);
            c.p(Particle.LARGE_SMOKE, 0, 5 * s, 0, 1, 1.5 * s, 0.02);
            if (power > 0.02) {
                double h = 70 * s * power;
                for (double y = 0; y < h; y += 1.4 * s) {
                    double w = (2.2 + 1.2 * Math.sin(y * 0.3 - c.t * 0.2)) * s;
                    Horror.ring(c, 0, y, 0, w, 6, c.t * 0.1, M.lerp(0x8A00FF, 0xFFFFFF, y / (h + 1)), 3.0);
                }
                c.p(Particle.ELECTRIC_SPARK, 0, h, 0, 6, 3 * s, 0.2);
            }
        }
    }

    // ------------------------------------------------------------ 7. ВРАТА АДА
    public static final class Hellgate implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 1800, u = (c.t % P) / P;
            double open = sm(u / 0.2) * (1 - sm((u - 0.92) / 0.08));
            double R = (6 + 14 * open) * s;
            c.yaw = 0.6;
            for (double r = 1.2 * s; r <= R; r += 1.8 * s) {
                int m = Math.max(6, (int) (r / s * 5));
                for (int k = 0; k < m; k++) {
                    double a = 2 * Math.PI * k / m + r * 0.15 - c.t * 0.01;
                    double heat = 0.5 + 0.5 * Math.sin(a * 3 + r * 0.5 - c.t * 0.05);
                    c.dust(r * Math.cos(a), 0.2, r * Math.sin(a), M.lerp(0x8A0000, 0xFFC000, heat), 2.8);
                }
            }
            Horror.ring(c, 0, 0.3, 0, R + 1.2 * s, c.n(80), 0, 0x1A0A0A, 3.4);
            for (int k = 0; k < 10; k++) {
                double a = 2 * Math.PI * k / 10 + 0.2, r2 = R + (8 + 16 * open) * s;
                L(c, (R + 1.2 * s) * Math.cos(a), 0.2, (R + 1.2 * s) * Math.sin(a), r2 * Math.cos(a + 0.1), 0.2, r2 * Math.sin(a + 0.1), 0xFF5000, 2.4);
            }
            for (int p = 0; p < 4; p++) {
                double hgt = Math.max(0, Math.sin(c.t * 0.02 + p * 1.9)) * 20 * s * open;
                double a = p * Math.PI / 2 + 0.5, x = R * 0.7 * Math.cos(a), z = R * 0.7 * Math.sin(a);
                for (double y = 0; y < hgt; y += 2 * s) {
                    c.p(Particle.FLAME, x, y, z, 2, 0.8 * s, 0.02);
                    c.cloud(x, y, z, 0xFF6000, 3.4, 2, 0.8 * s);
                }
            }
            double rise = sm((u - 0.35) / 0.3) * (1 - sm((u - 0.92) / 0.08));
            if (rise > 0.02) {
                for (int sd = -1; sd <= 1; sd += 2) {
                    for (int k = 0; k <= 24; k++) {
                        double f = k / 24.0;
                        double x = sd * (4 + 11 * Math.sin(f * 1.5)) * s, y = rise * 26 * s * Math.pow(f, 0.8);
                        c.dust(x, y, 0, M.lerp(0x1A1410, 0xD8CCB0, f), 4.0 - 2.2 * f);
                    }
                    c.p(Particle.FLAME, sd * 15 * s, rise * 26 * s, 0, 2, 0.4 * s, 0.02);
                    c.dust(sd * 3 * s, 12 * s * rise, 0, 0xFFE000, 3.9);
                }
            }
        }
    }

    // ------------------------------------------------------------ 8. ЛИЦО ДЕМОНА
    public static final class Demon implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            c.oy = 38 * s;
            c.yaw = 0.5;
            double jaw = 0.5 + 0.5 * Math.sin(c.t * 0.008);
            int n = c.n(64);
            for (int i = 0; i < n; i++) {
                double a = 2 * Math.PI * i / n, sn = Math.sin(a);
                double x = 13 * s * Math.cos(a) * (sn < 0 ? 0.65 + 0.35 * (1 + sn) : 1);
                double y = 16 * s * sn - (sn < 0 ? jaw * 6 * s * (-sn) : 0);
                c.dust(x, y, 0, 0x7A0C0C, 3.6);
            }
            for (int sd = -1; sd <= 1; sd += 2) {
                L(c, sd * 11 * s, 7 * s, 0, sd * 3 * s, 3.5 * s, 0, 0x180000, 3.8);
                double ex = sd * 6 * s, ey = 4.5 * s;
                for (double r = 0.5 * s; r <= 2.4 * s; r += 0.9 * s) {
                    int m = Math.max(6, (int) (r / s * 6));
                    for (int k = 0; k < m; k++) {
                        double a = 2 * Math.PI * k / m;
                        c.dust(ex + r * Math.cos(a), ey + r * Math.sin(a), 0, M.lerp(0xFFF0A0, 0xFF5A00, r / (2.4 * s)), 3.0);
                    }
                }
                L(c, ex, ey - 2.2 * s, 0.2, ex, ey + 2.2 * s, 0.2, 0x000000, 3.6);
                L(c, sd * 1.4 * s, -1 * s, 0, sd * 0.8 * s, -4 * s, 0, 0x000000, 3.4);
                for (int k = 0; k <= 14; k++) {
                    double f = k / 14.0;
                    double hx = sd * M.bez(9, 16, 24, 22, f) * s, hy = M.bez(13, 22, 28, 38, f) * s;
                    c.dust(hx, hy, 0, M.lerp(0x2A1410, 0xC8B890, f), 3.8 - 1.8 * f);
                    if (k == 14) c.p(Particle.FLAME, hx, hy, 0, 2, 0.4 * s, 0.02);
                }
            }
            double yu = -8 * s, yl = yu - (4 + 9 * jaw) * s;
            for (double x = -8 * s; x <= 8 * s; x += 1.6 * s) {
                double cu = yu - 0.05 * x * x / s;
                L(c, x, cu, 0, x, cu - 2.4 * s, 0, 0xF0F0E0, 2.8);
                L(c, x, yl, 0, x, yl + 2.2 * s, 0, 0xF0F0E0, 2.8);
                for (double y = yl + 2.4 * s; y < cu - 2.6 * s; y += 1.6 * s) {
                    if (((int) (x / s) + (int) (y / s) + c.frame & 1) == 0) c.dust(x, y, -0.3, jaw > 0.3 ? 0xFF3000 : 0x200000, 2.6);
                }
            }
        }
    }

    // ------------------------------------------------------------ 9. СЛЕНДЕР
    public static final class Slender implements Fx {
        final Rig g = new Rig();

        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 2400, u = (c.t % P) / P;
            int jump = c.t / 90;
            double a = Horror.hash(jump * 1.7) * 2 * Math.PI, dist = (52 - 34 * u) * s;
            g.set(dist * Math.cos(a), 0, dist * Math.sin(a), a + Math.PI, s);
            boolean gl = (c.t % 90) < 10;
            g.L(c, -0.5, 0, 0, -0.5, 10, 0, 0x050505, 3.0);
            g.L(c, 0.5, 0, 0, 0.5, 10, 0, 0x050505, 3.0);
            g.L(c, 0, 10, 0, 0, 19.5, 0, 0x050505, 3.8);
            g.L(c, -0.9, 19, 0, 0.9, 19, 0, 0x050505, 3.6);
            g.L(c, 0, 19.5, 0, 0, 21.5, 0, 0x050505, 3.0);
            g.L(c, 0, 19, 0.4, 0, 14, 0.4, 0x7A0000, 2.4);
            g.L(c, -0.9, 19, 0, -1.6, 5, 0.2, 0x050505, 2.6);
            g.L(c, 0.9, 19, 0, 1.6, 5, 0.2, 0x050505, 2.6);
            for (double r = 0.3; r <= 1.4; r += 0.5) {
                for (int k = 0; k < 10; k++) {
                    double an = 2 * Math.PI * k / 10;
                    g.D(c, r * Math.cos(an), 22.8 + 1.7 * r * Math.sin(an), 0.3, 0xF2F2F2, 2.8);
                }
            }
            for (int i = 0; i < 6; i++) {
                for (int j = 1; j <= 14; j++) {
                    double f = j / 14.0;
                    double side = (i - 2.5) * 2.4 * f + Math.sin(c.t * 0.05 + i + f * 5) * 1.2 * f;
                    double up = 18.5 + (8 + (i % 2) * 3) * Math.sin(f * 1.4);
                    g.D(c, side, up, -1 - f * 6, 0x050505, 2.6);
                }
            }
            if (gl) {
                for (int k = 0; k < 40; k++) {
                    double rx = (Horror.hash(c.t + k * 3.1) - 0.5) * 14, ry = Horror.hash(c.t * 0.7 + k * 5.3) * 26;
                    double rz = (Horror.hash(c.t * 1.3 + k * 7.7) - 0.5) * 8;
                    g.D(c, rx, ry, rz, k % 2 == 0 ? 0xFFFFFF : 0x000000, 3.0);
                }
                g.P(c, Particle.ELECTRIC_SPARK, 0, 12, 0, 6, 6, 0.1);
            }
        }
    }

    // ------------------------------------------------------------ 10. ТУМАН С ГЛАЗАМИ
    public static final class CreepFog implements Fx {
        static final int E = 16;
        final double[] ea = new double[E], ed = new double[E], eh = new double[E];

        public CreepFog() {
            Random r = new Random(9);
            for (int i = 0; i < E; i++) {
                ea[i] = r.nextDouble() * 2 * Math.PI;
                ed[i] = 6 + r.nextDouble() * 30;
                eh[i] = 1 + r.nextDouble() * 5;
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 1500, u = (c.t % P) / P;
            double ext = 0.55 + 0.45 * sm(u / 0.3);
            int n = c.n(90);
            for (int k = 0; k < n; k++) {
                double a = Horror.hash(k * 1.3) * 2 * Math.PI + c.t * 0.0015 * (k % 3 - 1);
                double d = (2 + Horror.hash(k * 9.1) * 42 * ext) * s;
                double y = (0.5 + Horror.hash(k * 2.2) * 2.5 + 0.6 * Math.sin(c.t * 0.012 + k)) * s;
                c.cloud(Math.cos(a) * d, y, Math.sin(a) * d, (k & 1) == 0 ? 0x2B3039 : 0x3F4652, 3.8, 3, 2.4 * s);
            }
            for (int i = 0; i < E; i++) {
                int slot = c.t / 50 + i * 13;
                if (Horror.hash(slot * 1.37 + i) < 0.35) continue;
                double a = ea[i] + 0.25 * Math.sin(c.t * 0.003 + i);
                double big = i == 0 ? 3 : 1;
                double d = ed[i] * s, x = Math.cos(a) * d, z = Math.sin(a) * d, y = eh[i] * s * big;
                int col = i % 3 == 0 ? 0xFF2020 : (i % 3 == 1 ? 0xFFE060 : 0xE8FFFF);
                double g = 0.45 * s * big, sx = -Math.sin(a), sz = Math.cos(a);
                c.dust(x + sx * g, y, z + sz * g, col, 3.6);
                c.dust(x - sx * g, y, z - sz * g, col, 3.6);
            }
            c.p(Particle.ASH, 0, 4 * s, 0, 6, 25 * s, 0.01);
        }
    }

    // ------------------------------------------------------------ 11. ПАДШИЙ СЕРАФИМ
    public static final class Seraph implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s;
            c.oy = (8 + 1.5 * Math.sin(c.t * 0.02)) * s;
            c.yaw = c.t * 0.0015;
            for (int l = 0; l < 18; l++) {
                double f = l / 17.0, r = (5 * (1 - f) + 1.2 * f) * s, h = f * 21 * s;
                for (int m = 0; m < 8; m++) {
                    if (((l + m + c.frame) & 1) != 0) continue;
                    double a = 2 * Math.PI * m / 8 + l * 0.25;
                    c.dust(r * Math.cos(a), h, r * Math.sin(a), (l + m) % 3 == 0 ? 0xFFF1B0 : 0xEFE8DA, 2.8);
                }
            }
            c.cloud(0, 23 * s, 0, 0xE6DED0, 3.2, 4, 0.8 * s);
            for (int sd = -1; sd <= 1; sd += 2) {
                c.dust(sd * 0.6 * s, 23.3 * s, 1.1 * s, 0xFF0000, 3.6);
                for (int j = 0; j < 4; j++) {
                    double y = 23.1 * s - ((c.t * 0.05 + j * 2.0 + (sd + 1)) % 9) * s;
                    c.dust(sd * 0.6 * s, y, 1.1 * s, 0xA00000, 2.0);
                }
            }
            for (int k = 0; k < 28; k++) {
                if (k % 7 == 0) continue;
                double a = 2 * Math.PI * k / 28 + c.t * 0.01;
                c.dust(3.2 * s * Math.cos(a), 27.5 * s + 0.4 * s * Math.sin(a), 3.2 * s * Math.sin(a), 0xFFD060, 2.6);
            }
            double flap = Math.sin(c.t * 0.03);
            for (int p = 0; p < 3; p++) {
                for (int sd = -1; sd <= 1; sd += 2) {
                    double sx = sd * 1.6 * s, sy = (18 - 3 * p) * s, sz = -0.3 * s * p, f0 = -0.1 + p * 0.8;
                    for (int j = 0; j < 10; j++) {
                        double ph = f0 + j * 0.19 + 0.2 * flap * (1 + 0.4 * p);
                        double len = (26 - 4 * p) * (0.5 + 0.5 * Math.sin(Math.PI * (j + 0.5) / 10)) * s;
                        double tx = sx + sd * Math.sin(ph) * len, ty = sy + Math.cos(ph) * len;
                        Horror.ln(c, sx, sy, sz, tx, ty, sz, 2.4, M.lerp(0xFFF4C8, 0x18040A, j / 10.0 * 0.8 + p * 0.1), 3.0);
                        if (p == 0 && j % 3 == 0) c.p(Particle.FLAME, tx, ty, sz, 1, 0.3 * s, 0.01);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ 12. НЕБЕСНЫЙ ЗМЕЙ
    public static final class Serpent implements Fx {
        static final int N = 96;

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            double[] xs = new double[N], ys = new double[N], zs = new double[N];
            for (int i = 0; i < N; i++) {
                double a = c.t * 0.006 - i * 0.055, R = (26 + 5 * Math.sin(a * 3)) * s;
                xs[i] = R * Math.cos(a);
                zs[i] = R * Math.sin(a);
                ys[i] = (32 + 9 * Math.sin(2 * a + c.t * 0.01) + 4 * Math.sin(a * 5 - c.t * 0.02)) * s;
            }
            for (int i = N - 1; i >= 0; i--) {
                double th = (i < 4 ? 2.8 : 2.5 - 1.7 * i / N) * s;
                c.cloud(xs[i], ys[i], zs[i], ((i / 3) & 1) == 0 ? 0x1F6A22 : 0xB4B41E, 3.8, 4, th * 0.55);
                if (i % 2 == 0) c.dust(xs[i], ys[i] - th * 0.6, zs[i], 0xE8E0A0, 2.4);
            }
            double dx = xs[0] - xs[1], dz = zs[0] - zs[1], l = Math.max(1e-6, Math.hypot(dx, dz));
            double fx = dx / l, fz = dz / l, nx = -fz, nz = fx;
            for (int sd = -1; sd <= 1; sd += 2) {
                c.dust(xs[0] + fx * 1.8 * s + nx * sd * 1.3 * s, ys[0] + 1.0 * s, zs[0] + fz * 1.8 * s + nz * sd * 1.3 * s, 0xFF0000, 3.9);
                double bx = xs[0] + fx * 2.2 * s + nx * sd * 0.7 * s, bz = zs[0] + fz * 2.2 * s + nz * sd * 0.7 * s;
                Horror.ln(c, bx, ys[0] - 0.4 * s, bz, bx, ys[0] - 2.8 * s, bz, 0.8, 0xFFFFF0, 2.4);
            }
            double len = (3 + 2 * Math.sin(c.t * 0.3)) * s;
            double bx = xs[0] + fx * 3.2 * s, bz = zs[0] + fz * 3.2 * s, by = ys[0] - 0.4 * s;
            double tx = bx + fx * len, tz = bz + fz * len;
            Horror.ln(c, bx, by, bz, tx, by, tz, 0.8, 0xFF2060, 2.4);
            for (int sd = -1; sd <= 1; sd += 2) {
                Horror.ln(c, tx, by, tz, tx + fx * s + nx * sd * 0.8 * s, by, tz + fz * s + nz * sd * 0.8 * s, 0.6, 0xFF2060, 2.4);
            }
        }
    }

    // ------------------------------------------------------------ 13. ЧАСЫ СУДНОГО ДНЯ
    public static final class DoomClock implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 22 * s, P = 1200, u = (c.t % P) / P;
            c.oy = 40 * s;
            c.yaw = 0.5;
            Horror.vring(c, 0, 0, 0, R, c.n(100), 0, 0xCFC8B8, 3.0);
            Horror.vring(c, 0, 0, 0, R * 0.93, c.n(90), 0, 0x6A6458, 2.4);
            for (int h = 0; h < 12; h++) {
                double a = 2 * Math.PI * h / 12, r1 = R * (h % 3 == 0 ? 0.76 : 0.84), r2 = R * 0.95;
                L(c, r1 * Math.sin(a), r1 * Math.cos(a), 0, r2 * Math.sin(a), r2 * Math.cos(a), 0, 0xFF2020, h % 3 == 0 ? 3.6 : 2.4);
            }
            double hm = u * 2 * Math.PI * 8, hh = u * 2 * Math.PI;
            L(c, 0, 0, 0, 0.5 * R * Math.sin(hh), 0.5 * R * Math.cos(hh), 0, 0xE8E0D0, 3.6);
            L(c, 0, 0, 0, 0.82 * R * Math.sin(hm), 0.82 * R * Math.cos(hm), 0, 0xE8E0D0, 3.2);
            c.dust(0.82 * R * Math.sin(hm), 0.82 * R * Math.cos(hm), 0, 0xFF0000, 3.9);
            c.cloud(0, 0, 0, 0xFF2020, 3.8, 3, 0.4 * s);
            for (int gr = 0; gr < 2; gr++) {
                double gcx = (gr == 0 ? -8 : 9) * s, gcy = (gr == 0 ? -6 : 7) * s, rot = (gr == 0 ? 1 : -1) * c.t * 0.02;
                for (int k = 0; k < 24; k++) {
                    double a = 2 * Math.PI * k / 24 + rot, r = (k % 2 == 0 ? 6 : 7.2) * s;
                    c.dust(gcx + r * Math.cos(a), gcy + r * Math.sin(a), -1 * s, 0x8A7A50, 2.4);
                }
            }
            if (u > 0.9) {
                for (int k = 0; k < 6; k++) {
                    double x = (-0.8 + k * 0.32) * R, y = -R - ((c.t * 0.05 + k * 3.1) % 14) * s;
                    c.dust(x, y, 0, 0xB00000, 2.6);
                }
            }
            if (u > 0.94) {
                double ph = (u - 0.94) / 0.06;
                for (int k = 0; k < 3; k++) {
                    double rr = (ph * 60 - k * 9) * s;
                    if (rr <= 0) continue;
                    int cnt = Math.max(16, Math.min(220, (int) (2 * Math.PI * rr / 1.5)));
                    Horror.vring(c, 0, 0, 0, rr, cnt, 0, 0xFF2020, 3.4);
                    Horror.ring(c, 0, -40 * s + 0.3, 0, rr, cnt, 0, 0xFF2020, 3.2);
                }
            }
        }
    }

    // ------------------------------------------------------------ 14. ЧЁРНОЕ СОЛНЦЕ
    public static final class BlackSun implements Fx {
        final double[][] fb = M.fib(260);

        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 14 * s, rot = c.t * 0.003;
            c.oy = 50 * s;
            double cr = Math.cos(rot), sr = Math.sin(rot);
            for (double[] p : fb) {
                double px = p[0] * cr + p[2] * sr, pz = -p[0] * sr + p[2] * cr, py = p[1];
                boolean crack = Math.abs(Math.sin(8 * px + 2.5 * Math.sin(6 * py) + 1.5 * Math.sin(5 * pz))) < 0.09;
                c.dust(px * R, py * R, pz * R,
                        crack ? M.lerp(0xFF3A00, 0xFFC040, 0.5 + 0.5 * Math.sin(c.t * 0.05 + px * 6)) : 0x060404,
                        crack ? 3.2 : 3.6);
            }
            for (int k = 0; k < 12; k++) {
                double a = 2 * Math.PI * k / 12 + rot, r2 = R * (1.3 + 0.25 * Math.sin(c.t * 0.03 + k * 2));
                L(c, R * 1.05 * Math.cos(a), R * 1.05 * Math.sin(a), 0, r2 * Math.cos(a), r2 * Math.sin(a), 0, 0x2A0A00, 3.0);
                c.dust(r2 * Math.cos(a), r2 * Math.sin(a), 0, 0xFF6A10, 3.0);
            }
            for (int k = 0; k < 6; k++) {
                double a = c.t * 0.005 + k * 1.05, r = (22 + 3 * Math.sin(k)) * s, y = 4 * Math.sin(a * 2 + k) * s;
                c.cloud(r * Math.cos(a), y, r * Math.sin(a), 0x201008, 3.6, 4, 1.0 * s);
                c.dust(r * Math.cos(a), y - 0.8 * s, r * Math.sin(a), 0xFF4A00, 2.4);
            }
            c.p(Particle.ASH, 0, -25 * s, 0, 50, 30 * s, 0.0);
        }
    }

    // ------------------------------------------------------------ 15. ГИГАНТСКИЙ МОЗГ
    public static final class Brain implements Fx {
        final double[][] fb = M.fib(170);

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            c.oy = 34 * s;
            c.yaw = c.t * 0.002;
            double pulse = 1 + 0.045 * Math.sin(c.t * 0.12) * (0.6 + 0.4 * Math.sin(c.t * 0.02));
            for (int hs = -1; hs <= 1; hs += 2) {
                for (double[] p : fb) {
                    double fold = 1 + 0.10 * Math.sin(9 * p[0] + 4 * p[1] + hs) * Math.sin(7 * p[2] + 3 * p[1]);
                    double k = fold * pulse;
                    c.dust(hs * 6.5 * s + p[0] * 7.5 * s * k, p[1] * 8.5 * s * k, p[2] * 11 * s * k,
                            M.lerp(0xC47A8C, 0x7A3A4E, 0.5 + 0.5 * Math.sin(fold * 12 + hs)), 3.2);
                }
            }
            L(c, 0, -6 * s, -2 * s, 1 * s, -18 * s, 0, 0xB86A7A, 3.4);
            L(c, 1 * s, -6 * s, -2 * s, 2 * s, -18 * s, 0, 0xA85A6A, 3.0);
            for (int k = 0; k < 3; k++) {
                int seed = c.t / 6 + k * 17;
                double[] p1 = fb[(int) (Horror.hash(seed * 1.13) * fb.length)];
                double[] p2 = fb[(int) (Horror.hash(seed * 2.71 + 5) * fb.length)];
                double hs = (k % 2 == 0) ? -1 : 1;
                double x1 = hs * 6.5 * s + p1[0] * 8 * s, y1 = p1[1] * 9 * s, z1 = p1[2] * 11 * s;
                Horror.ln(c, x1, y1, z1, hs * 6.5 * s + p2[0] * 8 * s, p2[1] * 9 * s, p2[2] * 11 * s, 1.5, 0xC8FFC0, 1.8);
                c.p(Particle.ELECTRIC_SPARK, x1, y1, z1, 2, 0.3, 0.1);
            }
            for (int k = 0; k < 3; k++) {
                double r = ((c.t * 0.35) + k * 14) % 42 * s;
                int cnt = Math.max(12, Math.min(140, (int) (2 * Math.PI * r / 1.5)));
                Horror.ring(c, 0, 0, 0, r, cnt, 0, M.lerp(0x39FF14, 0xFFE81F, k / 3.0), 3.0);
            }
        }
    }

    // ------------------------------------------------------------ 16. МЁРТВОЕ ДЕРЕВО
    public static final class DeadTree implements Fx {
        final List<double[]> br = new ArrayList<>();

        void gen(Random r, double x, double y, double z, double az, double el, double len, int d) {
            if (d > 5) return;
            double nx = x + len * Math.cos(el) * Math.cos(az), ny = y + len * Math.sin(el), nz = z + len * Math.cos(el) * Math.sin(az);
            br.add(new double[]{x, y, z, nx, ny, nz, d});
            int k = d < 2 ? 3 : 2;
            for (int i = 0; i < k; i++) {
                gen(r, nx, ny, nz, az + (r.nextDouble() - 0.5) * 2.2, Math.max(0.15, el + (r.nextDouble() - 0.5) * 0.9), len * 0.72, d + 1);
            }
        }

        public DeadTree() {
            gen(new Random(44), 0, 12, 0, 0, 1.1, 9, 0);
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            for (int k = 0; k < 3; k++) {
                double a = 2 * Math.PI * k / 3 + 0.4;
                L(c, 1.6 * s * Math.cos(a), 0, 1.6 * s * Math.sin(a), 0.6 * s * Math.cos(a + 0.8), 12 * s, 0.6 * s * Math.sin(a + 0.8), 0x1B1410, 3.8);
            }
            for (int k = 0; k < 6; k++) {
                double a = 2 * Math.PI * k / 6 + 0.2, r = (10 + 6 * Horror.hash(k * 3.3)) * s;
                L(c, 1.2 * s * Math.cos(a), 0.3, 1.2 * s * Math.sin(a), r * Math.cos(a + 0.3), 0.3, r * Math.sin(a + 0.3), 0x1B1410, 3.0);
            }
            for (double[] b : br) {
                double sw1 = 0.7 * s * Math.sin(c.t * 0.012 + b[1] * 0.2), sw2 = 0.7 * s * Math.sin(c.t * 0.012 + b[4] * 0.2);
                L(c, b[0] * s + sw1, b[1] * s, b[2] * s, b[3] * s + sw2, b[4] * s, b[5] * s, 0x1B1410, Math.max(1.4, 3.8 - 0.5 * b[6]));
            }
            double fl = 0.5 + 0.5 * Math.sin(c.t * 0.07);
            for (int sd = -1; sd <= 1; sd += 2) {
                c.dust(sd * 1.0 * s, 6.5 * s, 1.5 * s, M.lerp(0xFF6000, 0xFFD000, fl), 3.9);
                if (c.frame % 3 == 0) c.p(Particle.SOUL_FIRE_FLAME, sd * 1.0 * s, 6.7 * s, 1.6 * s, 1, 0.2 * s, 0.01);
            }
            double my = 1.4 * s * (0.5 + 0.5 * Math.sin(c.t * 0.02));
            for (int k = 0; k < 12; k++) {
                double a = 2 * Math.PI * k / 12;
                c.dust(0.9 * s * Math.cos(a), 3.5 * s + my * Math.sin(a), 1.5 * s, 0x000000, 3.6);
            }
            for (int k = 0; k < 24; k++) {
                double a = c.t * 0.01 * (1 + (k % 3) * 0.2) + k, r = (10 + Horror.hash(k * 2.1) * 10) * s;
                double y = (26 + 6 * Math.sin(c.t * 0.02 + k)) * s;
                c.dust(r * Math.cos(a), y, r * Math.sin(a), 0x000000, 3.0);
                c.dust(r * Math.cos(a), y + 0.7 * s * Math.sin(c.t * 0.5 + k), r * Math.sin(a), 0x151515, 2.0);
            }
            c.p(Particle.SOUL, 0, 16 * s, 0, 1, 10 * s, 0.01);
        }
    }

    // ------------------------------------------------------------ 17. ГИГАНТСКАЯ ГРУДНАЯ КЛЕТКА
    public static final class Ribcage implements Fx {
        final double[][] fb = M.fib(30);

        @Override
        public void tick(Ctx c) {
            double s = c.s, br = 1 + 0.04 * Math.sin(c.t * 0.03);
            c.yaw = 0.3;
            double prevR = -1, prevZ = 0;
            for (int j = 0; j < 9; j++) {
                double R = 15 * s * (1 - 0.55 * Math.pow((j - 4) / 4.5, 2)) * br, z = (j - 4) * 4.4 * s;
                int n = Math.max(12, (int) (Math.PI * R / 1.4));
                for (int k = 0; k <= n; k++) {
                    double a = Math.PI * k / n;
                    c.dust(R * Math.cos(a), R * 1.15 * Math.sin(a), z, M.lerp(0xE6DCC4, 0xA89878, Horror.hash(j * 7.1 + k * 0.37)), 3.2);
                }
                if (prevR > 0) L(c, 0, prevR * 1.15, prevZ, 0, R * 1.15, z, 0xCFC4A8, 3.0);
                prevR = R;
                prevZ = z;
            }
            double pr = 1 + 0.18 * Math.sin(c.t * 0.1);
            for (double[] p : fb) c.dust(p[0] * 2.2 * s * pr, 7 * s + p[1] * 2.2 * s * pr, p[2] * 2.2 * s * pr, 0x3AA0FF, 2.8);
            c.p(Particle.SOUL_FIRE_FLAME, 0, 7 * s, 0, 4, 1.5 * s, 0.03);
            c.p(Particle.SOUL, 0, 3 * s, 0, 1, 3 * s, 0.05);
        }
    }

    // ------------------------------------------------------------ 18. ДОЖДЬ ИЗ МЕЧЕЙ
    public static final class SwordRain implements Fx {
        static final int N = 36;
        final double[] sx = new double[N], sz = new double[N], so = new double[N], sp = new double[N];

        public SwordRain() {
            Random r = new Random(12);
            for (int i = 0; i < N; i++) {
                double a = r.nextDouble() * 2 * Math.PI, d = 2 + r.nextDouble() * 30;
                sx[i] = Math.cos(a) * d;
                sz[i] = Math.sin(a) * d;
                so[i] = r.nextDouble();
                sp[i] = 0.7 + r.nextDouble() * 0.6;
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            for (int i = 0; i < N; i++) {
                double cyc = (c.t * 0.0012 * sp[i] + so[i]) % 1.0, x = sx[i] * s, z = sz[i] * s;
                if (cyc > 0.95) continue;
                double f = Math.min(1, cyc / 0.7), tip = 62 * s * (1 - f * f);
                L(c, x, tip, z, x, tip + 5.5 * s, z, 0xC9D1DA, 2.8);
                L(c, x - 1.2 * s, tip + 5.5 * s, z, x + 1.2 * s, tip + 5.5 * s, z, 0x8A8A92, 2.6);
                L(c, x, tip + 5.5 * s, z, x, tip + 7.5 * s, z, 0x5A0A0A, 2.8);
                c.dust(x, tip + 7.8 * s, z, 0xB08030, 3.0);
                if (cyc < 0.7) {
                    for (int j = 0; j < 4; j++) c.dust(x, tip + (8.5 + j * 1.8) * s, z, M.lerp(0xFF4040, 0x300000, j / 4.0), 2.2);
                } else if (cyc < 0.7035) {
                    c.p(Particle.ELECTRIC_SPARK, x, 0.4, z, 10, 1.5 * s, 0.25);
                    Horror.ring(c, x, 0.3, z, 2 * s, 12, 0, 0xFFAA40, 3.0);
                }
            }
        }
    }

    // ------------------------------------------------------------ 19. ЧУМА
    public static final class Plague implements Fx {
        final double[][] fb = M.fib(40);

        @Override
        public void tick(Ctx c) {
            double s = c.s;
            for (int k = 0; k < 7; k++) {
                double a = 2 * Math.PI * k / 7 + 0.4, r = (k == 0 ? 0 : 2.6) * s, y = (k == 0 ? 3.4 : 1.2 + 0.4 * (k % 3)) * s;
                double x = r * Math.cos(a), z = r * Math.sin(a);
                for (int i = 0; i < 14; i++) {
                    double[] p = fb[i];
                    c.dust(x + p[0] * 1.1 * s, y + p[1] * 1.1 * s, z + p[2] * 1.1 * s, 0xD8D0B8, 2.4);
                }
                c.dust(x - 0.4 * s, y + 0.2 * s, z + 1.0 * s, 0x000000, 2.6);
                c.dust(x + 0.4 * s, y + 0.2 * s, z + 1.0 * s, 0x000000, 2.6);
            }
            int n = c.n(70);
            for (int k = 0; k < n; k++) {
                double a = Horror.hash(k * 1.9) * 2 * Math.PI + c.t * 0.004, d = (2 + Horror.hash(k * 3.3) * 26) * s;
                double y = (Horror.hash(k * 8.1) * 14 + (c.t * 0.02 + k) % 6) * s;
                c.cloud(Math.cos(a) * d, y, Math.sin(a) * d, (k & 1) == 0 ? 0x5E7A18 : 0x7A9A28, 3.6, 2, 2 * s);
            }
            int fl = c.n(110);
            for (int k = 0; k < fl; k++) {
                double ra = (6 + Horror.hash(k * 4.1) * 10) * s, ang = c.t * (0.05 + Horror.hash(k * 1.9) * 0.08) + Horror.hash(k) * 6.28;
                double y = (5 + (ra / s - 6) * 0.5 + 3 * Math.sin(ang * 3 + k)) * s;
                c.dust(ra * Math.cos(ang), y, ra * Math.sin(ang), 0x000000, 1.4);
            }
            for (int b = 0; b < 6; b++) {
                double cy = (c.t * 0.006 + b * 0.17) % 1.0;
                double a = Horror.hash(b * 6.7) * 2 * Math.PI, d = (3 + Horror.hash(b * 2.3) * 8) * s;
                double bx = Math.cos(a) * d, bz = Math.sin(a) * d, by = 0.6 * s;
                if (cy < 0.9) {
                    double r = cy * 2.2 * s;
                    for (double[] p : fb) c.dust(bx + p[0] * r, by + p[1] * r, bz + p[2] * r, 0x9ACD32, 2.0);
                } else if (cy < 0.915) {
                    c.p(Particle.WARPED_SPORE, bx, by + 1.5 * s, bz, 12, 1.5 * s, 0.05);
                }
            }
        }
    }

    // ------------------------------------------------------------ 20. ГИПНОЗ
    public static final class Hypno implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 24 * s, rot = c.t * 0.02;
            c.oy = 46 * s;
            c.yaw = 0.5;
            int n = c.n(150);
            for (int arm = 0; arm < 2; arm++) {
                for (int j = 0; j <= n; j++) {
                    double th = j / (double) n * 8 * Math.PI, f = th / (8 * Math.PI), r = f * R, a = th + rot + arm * Math.PI;
                    c.dust(r * Math.cos(a), r * Math.sin(a), 0, arm == 0 ? 0xF2F2F2 : 0x7A00B0, 2.6 + 1.2 * f);
                }
            }
            for (int k = 0; k < 3; k++) {
                double life = ((c.t * 0.4) + k * 20) % 60 / 60.0, rr = life * R * 1.3;
                Horror.vring(c, 0, 0, -0.2, rr, c.n(70), 0, M.lerp(0xFF3060, 0x300010, life), 2.4);
            }
            c.dust(0, 0, 0.1, 0xFF0000, 4.0);
            Horror.vring(c, 0, 0, 0.1, 1.5 * s, 12, 0, 0x000000, 3.4);
            for (int arm = 0; arm < 2; arm++) {
                for (int j = 0; j <= n; j++) {
                    double th = j / (double) n * 6 * Math.PI, f = th / (6 * Math.PI), r = f * 18 * s, a = th - rot + arm * Math.PI;
                    c.dust(r * Math.cos(a), -46 * s + 0.3, r * Math.sin(a), arm == 0 ? 0x000000 : 0xC00000, 3.0);
                }
            }
        }
    }

    // ------------------------------------------------------------ 21. КОСТЯНАЯ КЛЕТКА
    public static final class Cage implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 1400, u = (c.t % P) / P;
            double yB = 70 * s * (1 - sm(u / 0.45));
            if (u > 0.9) yB += sm((u - 0.9) / 0.1) * 70 * s;
            double close = sm((u - 0.5) / 0.25), R = 15 * s, H = 22 * s, topR = R * (1 - 0.88 * close);
            int B = 14;
            for (int b = 0; b < B; b++) {
                double a = 2 * Math.PI * b / B + 0.2, bx = R * Math.cos(a), bz = R * Math.sin(a);
                L(c, bx, yB, bz, topR * Math.cos(a), yB + H * (1 + 0.1 * close), topR * Math.sin(a), 0xD8CFB8, 3.0);
                L(c, bx, yB, bz, bx, yB - 3 * s, bz, 0xFFF2D0, 2.6);
            }
            for (double r = 0.3; r < 0.7; r += 0.3) {
                Horror.ring(c, 0, yB + H * r, 0, R + (topR - R) * r, c.n(60), 0, 0xB8AE98, 2.6);
            }
            Horror.ring(c, 0, yB + H, 0, topR, c.n(40), 0, 0xB8AE98, 2.8);
            if (close > 0.9) c.cloud(0, yB + H + 1 * s, 0, 0xEFE8D2, 3.6, 5, 0.8 * s);
            if (u >= 0.45 && u < 0.46) {
                c.p(Particle.ELECTRIC_SPARK, 0, 0.3, 0, 30, R, 0.3);
                c.p(Particle.LARGE_SMOKE, 0, 0.5, 0, 20, R * 0.8, 0.05);
            }
            if (close > 0.3 && u < 0.9) c.p(Particle.SOUL, 0, 2 * s, 0, 1, R * 0.4, 0.02);
        }
    }

    // ------------------------------------------------------------ 22. ВОЙ ВОЛКА ПОД КРОВАВОЙ ЛУНОЙ
    public static final class Howl implements Fx {
        static final double[][] W = {{-8, -16}, {-7, -6}, {-6, 0}, {-5.5, 6}, {-5, 11}, {-3.2, 7.5}, {-1, 8.5}, {3, 13},
                {9, 19}, {10, 17.5}, {4.5, 11.5}, {8.5, 13.5}, {8, 12}, {2.5, 6}, {0, 0}, {1, -8}, {1, -16}};

        @Override
        public void tick(Ctx c) {
            double s = c.s, P = 1800, u = (c.t % P) / P, R = 18 * s;
            double rise = sm(u / 0.12) * (1 - sm((u - 0.94) / 0.06));
            c.oy = (-10 + 56 * rise) * s;
            c.yaw = 0.4;
            double st = 1.7 * s;
            for (double gx = -R; gx <= R; gx += st) {
                for (double gy = -R; gy <= R; gy += st) {
                    if (gx * gx + gy * gy > R * R) continue;
                    if (((int) (gx / st) + (int) (gy / st) + c.frame & 1) != 0) continue;
                    c.dust(gx, gy, -0.5 * s, Horror.hash((int) (gx * 0.7) + (int) (gy * 0.9) * 31) < 0.15 ? 0xC09060 : 0xE0B080, 3.2);
                }
            }
            for (double u1 = -9; u1 <= 11; u1 += 1.3) {
                for (double v1 = -16; v1 <= 19; v1 += 1.3) {
                    if (inPoly(W, u1, v1)) c.dust(u1 * s, (v1 - 3) * s, 0.3 * s, 0x05050A, 3.6);
                }
            }
            for (int i = 0; i < W.length; i++) {
                double[] a = W[i], b = W[(i + 1) % W.length];
                L(c, a[0] * s, (a[1] - 3) * s, 0.3 * s, b[0] * s, (b[1] - 3) * s, 0.3 * s, 0x000000, 3.0);
            }
            c.dust(-1 * s, 3.5 * s, 0.5 * s, 0xFFE020, 3.9);
            for (int k = 0; k < 3; k++) {
                double ph = ((c.t * 0.5 + k * 25) % 75) / 75.0, rr = ph * 34 * s;
                Horror.vring(c, 8 * s, 12 * s, 0.5 * s, rr, c.n(Math.max(12, (int) (rr / s * 2.5))), 0, M.lerp(0xAFC8FF, 0x203060, ph), 2.6);
            }
        }
    }

    // ------------------------------------------------------------ 23. ВСАДНИК БЕЗ ГОЛОВЫ
    public static final class Horseman implements Fx {
        final Rig g = new Rig();

        @Override
        public void tick(Ctx c) {
            double s = c.s, a = c.t * 0.008, R = 30 * s, gal = c.t * 0.22;
            g.set(R * Math.cos(a), (24 + 4 * Math.sin(c.t * 0.01)) * s, R * Math.sin(a), a + Math.PI / 2, s);
            for (double f = -4; f <= 4; f += 1.6) g.C(c, 0, 0.5 + 0.3 * Math.sin(gal + f), f, 0x0A0505, 3.8, 8, 1.3);
            g.L(c, 0, 1, 4, 0, 5, 6.5, 0x0A0505, 3.8);
            g.L(c, 0, 5, 6.5, 0, 4, 9, 0xD8D0B8, 3.2);
            g.D(c, 0.5, 5.4, 7, 0xFF4000, 3.9);
            g.D(c, -0.5, 5.4, 7, 0xFF4000, 3.9);
            g.P(c, Particle.FLAME, 0, 4, 5.5, 3, 0.5, 0.03);
            g.P(c, Particle.FLAME, 0, 1, -5, 4, 0.6, 0.05);
            double[] lp = {3.5, 3.5, -3.5, -3.5}, lz = {0.8, -0.8, 0.8, -0.8};
            for (int j = 0; j < 4; j++) {
                double ph = gal + j * 1.6, sw = Math.sin(ph) * 1.8, lift = Math.max(0, Math.cos(ph)) * 1.2;
                g.L(c, lz[j], -0.5, lp[j], lz[j], -3 + lift * 0.5, lp[j] + sw * 0.5, 0x0A0505, 2.8);
                g.L(c, lz[j], -3 + lift * 0.5, lp[j] + sw * 0.5, lz[j], -5 + lift, lp[j] + sw, 0xD8D0B8, 2.4);
            }
            g.L(c, 0, 1.2, -0.5, 0, 6.5, 0.2, 0x140A1A, 3.8);
            g.L(c, -1.1, 6, 0.2, 1.1, 6, 0.2, 0x140A1A, 3.4);
            g.L(c, 1.1, 6, 0.2, 2.2, 9, 1.0, 0x140A1A, 2.8);
            g.L(c, 2.2, 9, 1.0, 2.6, 17, 1.5, 0xCFD6E0, 3.0);
            g.P(c, Particle.FLAME, 2.6, 16, 1.5, 3, 0.4, 0.03);
            g.L(c, -1.1, 6, 0.2, -1.6, 3.5, 1.5, 0x140A1A, 2.8);
            g.P(c, Particle.SOUL_FIRE_FLAME, 0, 7.8, 0.2, 3, 0.3, 0.02);
            g.L(c, 0.9, 1.2, 0, 1.3, -1.5, 1.0, 0x140A1A, 2.8);
            g.L(c, -0.9, 1.2, 0, -1.3, -1.5, 1.0, 0x140A1A, 2.8);
            for (int k = 0; k < 3; k++) {
                g.L(c, (k - 1) * 1.0, 6.2, 0, (k - 1) * 1.6 + Math.sin(gal * 0.5 + k), 3.5 + Math.sin(gal * 0.5 + k), -7, 0x300A0A, 3.0);
            }
            g.P(c, Particle.LARGE_SMOKE, 0, -4, -4, 1, 1, 0.02);
        }
    }

    // ------------------------------------------------------------ 24. КРОВАВАЯ РЕКА
    public static final class BloodRiver implements Fx {
        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 22 * s, W = 4.5 * s;
            int segs = c.n(130);
            for (int lane = 0; lane < 4; lane++) {
                double rr = R + (lane - 1.5) * W / 2.4;
                for (int k = 0; k < segs; k++) {
                    if (((k + lane + c.frame) & 1) != 0) continue;
                    double a = 2 * Math.PI * k / segs + c.t * 0.006 + lane * 0.3;
                    c.dust(rr * Math.cos(a), 0.25, rr * Math.sin(a), ((k / 3 + lane) & 1) == 0 ? 0x8A0000 : 0xC21010, 3.2);
                }
            }
            for (int i = 0; i < 5; i++) {
                double fa = c.t * 0.006 + 2 * Math.PI * i / 5, pp = (c.t * 0.005 + i * 0.2) % 1.0;
                double raise = sm(pp / 0.2) * (1 - sm((pp - 0.8) / 0.2));
                if (raise < 0.1) continue;
                double x = R * Math.cos(fa), z = R * Math.sin(fa), tx = -Math.sin(fa), tz = Math.cos(fa), y = raise * 3 * s;
                for (int q = 0; q < 14; q++) {
                    double th = 2 * Math.PI * q / 14;
                    c.dust(x + tx * 1.6 * s * Math.cos(th), y + 2.2 * s * Math.sin(th), z + tz * 1.6 * s * Math.cos(th), 0xD8C0B8, 2.6);
                }
                for (int sd = -1; sd <= 1; sd += 2) {
                    c.dust(x + tx * sd * 0.7 * s, y + 0.7 * s, z + tz * sd * 0.7 * s, 0x000000, 3.4);
                }
                for (int q = 0; q < 6; q++) {
                    double th = 2 * Math.PI * q / 6;
                    c.dust(x + tx * 0.6 * s * Math.cos(th), y - 0.9 * s + 0.8 * s * Math.sin(th), z + tz * 0.6 * s * Math.cos(th), 0x000000, 3.0);
                }
            }
            double a2 = c.t * 0.01;
            c.p(Particle.CRIMSON_SPORE, R * Math.cos(a2), 1, R * Math.sin(a2), 3, 3 * s, 0);
        }
    }

    // ------------------------------------------------------------ 25. ВЕНДИГО
    public static final class Wendigo implements Fx {
        final Rig g = new Rig();
        final List<double[]> ant = new ArrayList<>();
        final double[][] fb = M.fib(18);

        void gen(Random r, double x, double y, double z, double az, double el, double len, int d) {
            if (d > 4) return;
            double nx = x + len * Math.cos(el) * Math.cos(az), ny = y + len * Math.sin(el), nz = z + len * Math.cos(el) * Math.sin(az);
            ant.add(new double[]{x, y, z, nx, ny, nz, d});
            for (int i = 0; i < 2; i++) {
                gen(r, nx, ny, nz, az + (r.nextDouble() - 0.5) * 2.2, Math.max(0.2, el + (r.nextDouble() - 0.5) * 0.8), len * 0.74, d + 1);
            }
        }

        public Wendigo() {
            Random r = new Random(21);
            gen(r, 0.9, 27.5, 0.8, 0, 0.9, 5, 0);
            gen(r, -0.9, 27.5, 0.8, Math.PI, 0.9, 5, 0);
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s, ang = 0.35 * Math.sin(c.t * 0.0018) + c.t * 0.0006, R = (40 - 8 * Math.sin(c.t * 0.002)) * s;
            g.set(R * Math.cos(ang), 0, R * Math.sin(ang), ang + Math.PI, s);
            double sway = 0.35 * Math.sin(c.t * 0.015), hd = sway * 1.4;
            for (int sd = -1; sd <= 1; sd += 2) {
                g.L(c, sd * 1.2, 13, 0, sd * 1.8, 7.5, 0.8, 0x3A2A1E, 3.0);
                g.L(c, sd * 1.8, 7.5, 0.8, sd * 1.4, 3, -0.4, 0x3A2A1E, 3.0);
                g.L(c, sd * 1.4, 3, -0.4, sd * 1.6, 0.2, 1.2, 0x2A1E16, 3.0);
                g.C(c, sd * 1.5, 9, 0, 0x1A120C, 3.4, 3, 1.2);
                g.L(c, sd * 2.4, 23.5, 0, sd * 3.4, 15, 0.5, 0xCFC6AE, 2.6);
                g.L(c, sd * 3.4, 15, 0.5, sd * 3.0, 4.5, 1.5, 0xCFC6AE, 2.6);
                for (int f = 0; f < 3; f++) {
                    g.L(c, sd * 3.0, 4.5, 1.5, sd * (3.0 + (f - 1) * 0.5), 0.6, 2.4 + f * 0.3, 0xE8E0CC, 2.2);
                }
            }
            g.L(c, 0, 13, 0, sway * 0.5, 18, 0, 0x3A2A1E, 3.2);
            g.L(c, sway * 0.5, 18, 0, sway, 24, 0.3, 0x3A2A1E, 3.2);
            for (int r = 0; r < 7; r++) {
                double y = 15.5 + r * 1.2, w = 1.7 - 0.12 * r;
                g.L(c, 0, y, -0.3, w, y - 0.3, 0.8, 0xD8CFB8, 2.2);
                g.L(c, 0, y, -0.3, -w, y - 0.3, 0.8, 0xD8CFB8, 2.2);
            }
            g.L(c, sway, 24, 0.3, hd, 26.5, 0.8, 0x3A2A1E, 3.0);
            for (double[] p : fb) g.D(c, hd + p[0] * 0.9, 27.5 + p[1] * 1.1, 1.3 + p[2] * 1.6, 0xE8E0CC, 2.6);
            g.D(c, hd + 0.5, 27.8, 2.7, 0xAFE8FF, 3.9);
            g.D(c, hd - 0.5, 27.8, 2.7, 0xAFE8FF, 3.9);
            for (double[] b : ant) {
                g.L(c, b[0] + hd, b[1], b[2], b[3] + hd, b[4], b[5], 0xCFC6AE, Math.max(1.4, 2.8 - 0.3 * b[6]));
            }
            if (c.frame % 2 == 0) g.P(c, Particle.CLOUD, hd, 26.8, 3.2, 1, 0.3, 0.02);
        }
    }

    // ------------------------------------------------------------ 26-28. РОИ ТЁМНЫХ ПОЛОСОК (как swarm, но жуткие)
    /** Сотни полосок-следов медленно плывут по огромному небу. Палитра задаёт цвет. */
    public static final class Streaks implements Fx {
        static final int N = 480, T = 10;
        final double[][] home = new double[N][], a = new double[N][18];
        final int[] pal;
        final int fade;

        public Streaks(int[] pal, int fade, long seed) {
            this.pal = pal;
            this.fade = fade;
            Random r = new Random(seed);
            for (int i = 0; i < N; i++) {
                double[] d = M.norm(new double[]{r.nextGaussian(), r.nextGaussian(), r.nextGaussian()});
                double rad = 85 * Math.cbrt(r.nextDouble());
                home[i] = new double[]{d[0] * rad, d[1] * rad * 0.6, d[2] * rad};
                for (int k = 0; k < 3; k++) {
                    a[i][k * 6] = 8 + r.nextDouble() * 14;
                    a[i][k * 6 + 1] = 0.0012 + r.nextDouble() * 0.0022;
                    a[i][k * 6 + 2] = r.nextDouble() * 2 * Math.PI;
                    a[i][k * 6 + 3] = 5 + r.nextDouble() * 8;
                    a[i][k * 6 + 4] = 0.003 + r.nextDouble() * 0.004;
                    a[i][k * 6 + 5] = r.nextDouble() * 2 * Math.PI;
                }
            }
        }

        private double pos(int i, int k, double tt, double s) {
            double[] q = a[i];
            double wind = k == 0 ? 30 * Math.sin(tt * 0.0006) : (k == 1 ? 6 * Math.sin(tt * 0.0009) : 0);
            return s * (home[i][k] + wind + q[k * 6] * Math.sin(q[k * 6 + 1] * tt + q[k * 6 + 2])
                    + q[k * 6 + 3] * Math.sin(q[k * 6 + 4] * tt + q[k * 6 + 5]));
        }

        @Override
        public void tick(Ctx c) {
            c.oy = 60 * c.s;
            int tl = c.n(T);
            for (int i = 0; i < N; i++) {
                int col = pal[i % pal.length];
                for (int j = 0; j < tl; j++) {
                    double tt = c.t - j * 12.0;
                    c.dust(pos(i, 0, tt, c.s), pos(i, 1, tt, c.s), pos(i, 2, tt, c.s), M.lerp(col, fade, j / (double) tl), 3.0 - 1.6 * j / tl);
                }
            }
        }
    }

    // ------------------------------------------------------------ 29. ЗЕЛЁНЫЙ ШАР ИЗ ПОЛОСОК
    /** Тысячи мелких зелёных полосок плавно текут в одну сторону по кругам и складываются в шар. Бесконечный цикл. */
    public static final class GreenOrb implements Fx {
        static final int N = 2000;
        static final int[] PAL = {0x39FF14, 0x1FBF2A, 0x7CFF5A, 0x0FA030, 0xA8FF80};
        final double[] ly = new double[N], lp = new double[N], lr = new double[N];

        public GreenOrb() {
            Random r = new Random(31);
            for (int i = 0; i < N; i++) {
                ly[i] = r.nextDouble() * 2 - 1;
                lp[i] = r.nextDouble() * 2 * Math.PI;
                lr[i] = 0.9 + 0.2 * r.nextDouble();
            }
        }

        @Override
        public void tick(Ctx c) {
            double s = c.s, R = 14 * s, breathe = 1 + 0.03 * Math.sin(c.t * 0.01);
            c.oy = 12 * s;
            int tl = Math.max(2, c.n(3));
            for (int i = 0; i < N; i++) {
                double y = ly[i], cl = Math.sqrt(1 - y * y), rad = R * lr[i] * breathe, rxz = rad * cl;
                double ph = lp[i] + 0.012 * (0.85 + 0.3 * cl) * c.t;
                double dph = Math.min(0.3, 0.8 * s / Math.max(0.5 * s, rxz));
                int col = PAL[i % PAL.length];
                for (int j = 0; j < tl; j++) {
                    double a = ph - j * dph;
                    c.dust(rxz * Math.cos(a), y * rad, rxz * Math.sin(a), M.lerp(col, 0x052A0A, j / (double) tl), 2.2 - 0.7 * j / tl);
                }
            }
        }
    }
}
